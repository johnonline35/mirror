"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StructuredDataModule = void 0;
const common_1 = require("@nestjs/common");
const structured_data_service_1 = require("./structured-data.service");
const structured_data_controller_1 = require("./structured-data.controller");
const job_manager_module_1 = require("../job-manager/job-manager.module");
const components_registry_module_1 = require("../components-registry/components-registry.module");
let StructuredDataModule = class StructuredDataModule {
};
exports.StructuredDataModule = StructuredDataModule;
exports.StructuredDataModule = StructuredDataModule = __decorate([
    (0, common_1.Module)({
        imports: [job_manager_module_1.JobManagerModule, components_registry_module_1.ComponentsRegistryModule],
        controllers: [structured_data_controller_1.StructuredDataController],
        providers: [structured_data_service_1.StructuredDataService],
        exports: [structured_data_service_1.StructuredDataService],
    })
], StructuredDataModule);
//# sourceMappingURL=structured-data.module.js.map