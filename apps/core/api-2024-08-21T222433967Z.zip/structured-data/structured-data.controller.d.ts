import { StructuredDataService } from './structured-data.service';
import { StructuredDataDto } from './dtos/structured-data.dto';
export declare class StructuredDataController {
    private readonly structuredDataService;
    constructor(structuredDataService: StructuredDataService);
    handle(requestDto: StructuredDataDto): Promise<{
        jobId: any;
        result: any;
    }>;
    getJobStatus(jobId: string): Promise<any>;
}
