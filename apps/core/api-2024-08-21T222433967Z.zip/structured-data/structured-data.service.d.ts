import { JobManagerService } from '../job-manager/job-manager.service';
import { StructuredDataDto } from './dtos/structured-data.dto';
import { ComponentsRegistryService } from '../components-registry/components-registry.service';
export declare class StructuredDataService {
    private readonly jobManagerService;
    private readonly componentsRegistryService;
    constructor(jobManagerService: JobManagerService, componentsRegistryService: ComponentsRegistryService);
    handle(requestDto: StructuredDataDto): Promise<{
        jobId: any;
        result: any;
    }>;
    getJobStatus(jobId: string): Promise<any>;
}
