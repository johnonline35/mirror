"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StructuredDataService = void 0;
const common_1 = require("@nestjs/common");
const job_manager_service_1 = require("../job-manager/job-manager.service");
const task_interface_1 = require("../interfaces/task.interface");
const components_registry_service_1 = require("../components-registry/components-registry.service");
let StructuredDataService = class StructuredDataService {
    constructor(jobManagerService, componentsRegistryService) {
        this.jobManagerService = jobManagerService;
        this.componentsRegistryService = componentsRegistryService;
    }
    async handle(requestDto) {
        const { prompt, url, schema } = requestDto;
        let schemaString;
        try {
            schemaString =
                typeof schema === 'string' ? schema : JSON.stringify(schema);
        }
        catch (error) {
            throw new Error('Failed to stringify the schema');
        }
        console.log('schemaString', schemaString);
        const tools = this.componentsRegistryService.getComponentsByType(task_interface_1.TaskComponentType.TOOL);
        const utilities = this.componentsRegistryService.getComponentsByType(task_interface_1.TaskComponentType.UTILITY);
        const task = {
            type: 'structured-data-extraction',
            details: {
                prompt,
                url,
                schema: schemaString,
            },
            goal: `Your task is to extract structured data from the provided unstructured text. The data should be formatted as per the schema defined by the user. If the schema is not correctly formated but it is clear what the user wants, then correct the schema but retain as closely as possible what the user wants. The specified user-defined schema is as follows: ${schemaString}.`,
            components: [...tools, ...utilities],
        };
        const jobResult = await this.jobManagerService.createJob(task);
        return { jobId: jobResult.jobId, result: jobResult.result };
    }
    async getJobStatus(jobId) {
        return this.jobManagerService.getJobStatus(jobId);
    }
};
exports.StructuredDataService = StructuredDataService;
exports.StructuredDataService = StructuredDataService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [job_manager_service_1.JobManagerService,
        components_registry_service_1.ComponentsRegistryService])
], StructuredDataService);
//# sourceMappingURL=structured-data.service.js.map