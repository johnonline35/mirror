"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bootstrap_1 = require("./bootstrap");
(0, bootstrap_1.bootstrap)(false, true).then(async (nestApp) => {
    const port = process.env.PORT || 3334;
    return nestApp.listen(port);
});
//# sourceMappingURL=main.js.map