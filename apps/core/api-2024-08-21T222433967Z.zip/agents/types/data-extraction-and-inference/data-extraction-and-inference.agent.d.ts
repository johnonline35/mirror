import { Logger } from '@nestjs/common';
import { AgentState } from '../../common/agent-state';
import { ITask } from '../../../interfaces/task.interface';
import { IAgent } from '../../common/agent.interface';
import { TemplatesService } from '../../../llm/templates/templates.service';
import { OpenAiService } from '../../../llm/llm-providers/openai/openai.service';
import { ExtractedDataContext } from './data-extraction-and-inference.interface';
import { ExtractedPageData } from '../../../tools/crawler/strategies/crawler-strategies/crawler-strategy.interface';
export declare class DataExtractionAndInferenceAgent implements IAgent {
    private readonly templatesService;
    private readonly openAiService;
    state: AgentState<ExtractedDataContext & ITask>;
    protected readonly logger: Logger;
    constructor(templatesService: TemplatesService, openAiService: OpenAiService);
    private initializeAgent;
    execute(task: ITask, pageData: ExtractedPageData): Promise<ExtractedDataContext>;
    handleError(error: Error, context: ExtractedDataContext & ITask): Promise<void>;
}
