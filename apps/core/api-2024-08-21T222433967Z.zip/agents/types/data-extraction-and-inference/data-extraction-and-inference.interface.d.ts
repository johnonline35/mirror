export interface ExtractedDataContext<T = any> {
    url?: string;
    jsonifiedData?: T;
}
