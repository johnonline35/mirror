export interface CrawlHomepageContext<T = any> {
    homepageData?: T;
}
