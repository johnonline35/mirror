import { Logger } from '@nestjs/common';
import { AgentState } from '../../common/agent-state';
import { ITask } from '../../../interfaces/task.interface';
import { IAgent } from '../../common/agent.interface';
import { CrawlHomepageContext } from './crawl-homepage.interface';
import { CrawlerService } from '../../../tools/crawler/crawler.service';
export declare class CrawlHomepageAgent implements IAgent {
    private readonly crawlerService;
    state: AgentState<CrawlHomepageContext & ITask>;
    protected readonly logger: Logger;
    constructor(crawlerService: CrawlerService);
    private initializeAgent;
    execute(task: ITask): Promise<CrawlHomepageContext>;
    handleError(error: Error, context: CrawlHomepageContext & ITask): Promise<void>;
}
