export interface CrawlSitePlanningContext<T = any> {
    plan?: T;
}
export interface LlmCrawlingPlan {
    plan?: string;
}
