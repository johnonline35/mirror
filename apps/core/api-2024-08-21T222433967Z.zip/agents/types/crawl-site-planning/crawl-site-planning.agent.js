"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CrawlSitePlanningAgent_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlSitePlanningAgent = void 0;
const common_1 = require("@nestjs/common");
const agent_state_1 = require("../../common/agent-state");
const agent_registry_1 = require("../../common/agent-registry");
const templates_service_1 = require("../../../llm/templates/templates.service");
const openai_service_1 = require("../../../llm/llm-providers/openai/openai.service");
let CrawlSitePlanningAgent = CrawlSitePlanningAgent_1 = class CrawlSitePlanningAgent {
    constructor(templatesService, openAiService) {
        this.templatesService = templatesService;
        this.openAiService = openAiService;
        this.logger = new common_1.Logger(CrawlSitePlanningAgent_1.name);
    }
    async initializeAgent(task) {
        this.state = new agent_state_1.AgentState(task);
        this.state.setInitialized();
        this.logger.log(`Initializing ValidatePromptAgent with task: ${JSON.stringify(task)}`);
    }
    async execute(task, homepageData) {
        this.initializeAgent(task);
        if (!this.state.initialized) {
            throw new Error('Agent not initialized');
        }
        this.logger.log(`Executing: ${JSON.stringify(task)}`);
        try {
            const siteCrawlPlanTemplate = this.templatesService.getSiteCrawlPlanTemplate('2.0');
            console.log('homepageData:', homepageData);
            const renderedTemplate = siteCrawlPlanTemplate.render({
                task: task,
                homepageData: homepageData,
            });
            console.log(`Rendered siteCrawlPlan before submit: ${renderedTemplate}`);
            const llmOptions = {
                model: 'gpt-4o-mini-2024-07-18',
                maxTokens: 1000,
                temperature: 1,
            };
            const initialPlan = await this.openAiService.adapt(renderedTemplate, llmOptions);
            console.log(`Received site crawling plan from LLM: ${initialPlan}`);
            this.state.context.plan = initialPlan;
            this.state.setExecuted();
            return this.state.context;
        }
        catch (error) {
            this.handleError(error, this.state.context);
            throw error;
        }
    }
    async handleError(error, context) {
        this.state.setError(error);
        this.logger.error(`Error occurred while processing task ${JSON.stringify(context)}`, error.stack);
    }
};
exports.CrawlSitePlanningAgent = CrawlSitePlanningAgent;
exports.CrawlSitePlanningAgent = CrawlSitePlanningAgent = CrawlSitePlanningAgent_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, agent_registry_1.RegisterAgent)(agent_registry_1.AgentType.CrawlSitePlanningAgent),
    __metadata("design:paramtypes", [templates_service_1.TemplatesService,
        openai_service_1.OpenAiService])
], CrawlSitePlanningAgent);
//# sourceMappingURL=crawl-site-planning.agent.js.map