export interface ReviewedDataContext<T = any> {
    data?: T;
}
