export interface CrawlPageContext<T = any> {
    pageData?: T;
}
