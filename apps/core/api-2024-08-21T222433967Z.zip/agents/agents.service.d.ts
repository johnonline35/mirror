import { IAgent } from './common/agent.interface';
import { AgentType } from './common/agent-registry';
import { ModuleRef } from '@nestjs/core';
export declare class AgentsService {
    private readonly moduleRef;
    constructor(moduleRef: ModuleRef);
    getAgent(agentType: AgentType): IAgent;
}
