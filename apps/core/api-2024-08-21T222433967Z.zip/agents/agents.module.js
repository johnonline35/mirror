"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentsModule = void 0;
const common_1 = require("@nestjs/common");
const common_module_1 = require("../common/common.module");
const llm_module_1 = require("../llm/llm.module");
const tools_module_1 = require("../tools/tools.module");
const agent_registry_1 = require("./common/agent-registry");
const agents_service_1 = require("./agents.service");
const validate_prompt_agent_1 = require("./types/validate-prompt/validate-prompt.agent");
const crawl_homepage_agent_1 = require("./types/crawl-homepage/crawl-homepage.agent");
const crawl_site_planning_agent_1 = require("./types/crawl-site-planning/crawl-site-planning.agent");
const crawl_page_agent_1 = require("./types/crawl-page/crawl-page.agent");
const data_extraction_and_inference_agent_1 = require("./types/data-extraction-and-inference/data-extraction-and-inference.agent");
const data_review_agent_1 = require("./types/data-review/data-review.agent");
let AgentsModule = class AgentsModule {
};
exports.AgentsModule = AgentsModule;
exports.AgentsModule = AgentsModule = __decorate([
    (0, common_1.Module)({
        imports: [common_module_1.CommonModule, llm_module_1.LlmModule, tools_module_1.ToolsModule],
        providers: [
            agents_service_1.AgentsService,
            validate_prompt_agent_1.ValidatePromptAgent,
            crawl_homepage_agent_1.CrawlHomepageAgent,
            crawl_page_agent_1.CrawlPageAgent,
            crawl_site_planning_agent_1.CrawlSitePlanningAgent,
            data_extraction_and_inference_agent_1.DataExtractionAndInferenceAgent,
            data_review_agent_1.DataReviewAgent,
            ...(0, agent_registry_1.getAgentProviders)(),
        ],
        exports: [agents_service_1.AgentsService],
    })
], AgentsModule);
//# sourceMappingURL=agents.module.js.map