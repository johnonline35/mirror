"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentType = exports.getAgentProviders = exports.createAgentRegistrySymbol = exports.createAgentSymbol = exports.RegisterAgent = void 0;
const agentRegistry = new Map();
function RegisterAgent(agentType) {
    return function (constructor) {
        console.log(`Registering agent: ${agentType}`);
        agentRegistry.set(agentType, constructor);
    };
}
exports.RegisterAgent = RegisterAgent;
function createAgentSymbol(agentType) {
    return `AGENT_${agentType}`;
}
exports.createAgentSymbol = createAgentSymbol;
const createAgentRegistrySymbol = () => `AGENT_REGISTRY`;
exports.createAgentRegistrySymbol = createAgentRegistrySymbol;
function getAgentProviders() {
    const providers = [];
    const providerKeys = new Set();
    for (const [type, agent] of agentRegistry.entries()) {
        providers.push({
            provide: createAgentSymbol(type),
            useClass: agent,
        });
        providerKeys.add(createAgentSymbol(type));
    }
    providers.push({
        provide: (0, exports.createAgentRegistrySymbol)(),
        useValue: providerKeys,
    });
    return providers;
}
exports.getAgentProviders = getAgentProviders;
var AgentType;
(function (AgentType) {
    AgentType["CrawlHomepageAgent"] = "CRAWL_HOMEPAGE_AGENT";
    AgentType["CrawlPageAgent"] = "CrawlPageAgent";
    AgentType["CrawlSitePlanningAgent"] = "CRAWL_SITE_PLANNING_AGENT";
    AgentType["DataExtractionAndInferenceAgent"] = "DATA_EXTRACTION_AND_INFERENCE_AGENT";
    AgentType["DataReviewAgent"] = "DATA_REVIEW_AGENT";
    AgentType["ReflectionAgent"] = "REFLECTION_AGENT";
    AgentType["ValidatePromptAgent"] = "VALIDATE_PROMPT_AGENT";
})(AgentType || (exports.AgentType = AgentType = {}));
//# sourceMappingURL=agent-registry.js.map