import { Provider } from '@nestjs/common';
export declare function RegisterAgent(agentType: AgentType): (constructor: any) => void;
export declare function createAgentSymbol(agentType: AgentType): string;
export declare const createAgentRegistrySymbol: () => string;
export declare function getAgentProviders(): Provider[];
export declare enum AgentType {
    CrawlHomepageAgent = "CRAWL_HOMEPAGE_AGENT",
    CrawlPageAgent = "CrawlPageAgent",
    CrawlSitePlanningAgent = "CRAWL_SITE_PLANNING_AGENT",
    DataExtractionAndInferenceAgent = "DATA_EXTRACTION_AND_INFERENCE_AGENT",
    DataReviewAgent = "DATA_REVIEW_AGENT",
    ReflectionAgent = "REFLECTION_AGENT",
    ValidatePromptAgent = "VALIDATE_PROMPT_AGENT"
}
