"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var JobManagerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobManagerService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/utils/prisma/prisma.service");
const workflow_service_1 = require("../workflow/workflow.service");
let JobManagerService = JobManagerService_1 = class JobManagerService {
    constructor(prisma, workflowService) {
        this.prisma = prisma;
        this.workflowService = workflowService;
        this.logger = new common_1.Logger(JobManagerService_1.name);
    }
    async createJob(task) {
        this.logger.log(`Creating job for task: ${JSON.stringify(task.details)}`);
        const job = await this.prisma.job.create({
            data: {
                status: 'started',
                url: task.details.url,
            },
        });
        const jobResult = await this.executeJob(job.jobId, task);
        return { jobId: job.jobId, result: jobResult };
    }
    async executeJob(jobId, task) {
        try {
            const result = await this.workflowService.handle(task);
            await this.updateJobStatus(jobId, 'done', result);
            return result;
        }
        catch (error) {
            this.logger.error(`Job execution failed for job ${jobId}:`, error);
            await this.updateJobStatus(jobId, 'failed');
            throw error;
        }
    }
    async updateJobStatus(jobId, status, data) {
        this.logger.log(`Updating job status for ${jobId} to ${status}`);
        const dataToUpdate = {
            status,
            data,
        };
        try {
            return await this.prisma.job.update({
                where: { jobId },
                data: dataToUpdate,
            });
        }
        catch (error) {
            this.logger.error(`Failed to update job status for ${jobId}`, error.stack);
            throw error;
        }
    }
    async getJobStatus(jobId) {
        return await this.prisma.job.findUnique({
            where: { jobId },
        });
    }
};
exports.JobManagerService = JobManagerService;
exports.JobManagerService = JobManagerService = JobManagerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        workflow_service_1.WorkflowService])
], JobManagerService);
//# sourceMappingURL=job-manager.service.js.map