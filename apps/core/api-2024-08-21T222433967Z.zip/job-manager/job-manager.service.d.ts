import { PrismaService } from '../common/utils/prisma/prisma.service';
import { ITask } from '../interfaces/task.interface';
import { WorkflowService } from '../workflow/workflow.service';
import { IJobManagerService } from './job-manager-service.interface';
export declare class JobManagerService implements IJobManagerService {
    private prisma;
    private workflowService;
    private readonly logger;
    constructor(prisma: PrismaService, workflowService: WorkflowService);
    createJob(task: ITask): Promise<any>;
    private executeJob;
    updateJobStatus(jobId: string, status: string, data?: any): Promise<any>;
    getJobStatus(jobId: string): Promise<any>;
}
