"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplateFactory = void 0;
const templateRegistry_1 = require("./templateRegistry");
class TemplateFactory {
    static createTemplate(type, version) {
        const templateConstructor = templateRegistry_1.templateMap[type];
        if (!templateConstructor) {
            throw new Error(`Unknown template type: ${type}`);
        }
        return templateConstructor(version);
    }
}
exports.TemplateFactory = TemplateFactory;
//# sourceMappingURL=%20templateFactory.js.map