"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.templateMap = exports.templateTypes = void 0;
const categoryClassificationTemplate_1 = require("./classification/categoryClassificationTemplate");
const siteCrawlPlanTemplate_1 = require("./agent-behaviors/planning/siteCrawlPlanTemplate");
const contentSummarizationTemplate_1 = require("./summarization/contentSummarizationTemplate");
const promptReviewTemplate_1 = require("./validation/promptReviewTemplate");
const reflectionTemplate_1 = require("./agent-behaviors/reflection/reflectionTemplate");
const structuredDataExtractionTemplate_1 = require("./extraction/structuredDataExtractionTemplate");
const structuredReviewedData_1 = require("./final-output/structuredReviewedData");
exports.templateTypes = {
    CLASSIFICATION: 'CLASSIFICATION',
    STRUCTURED_DATA_EXTRACTION: 'STRUCTURED_DATA_EXTRACTION',
    STRUCTURED_REVIEWED_DATA: 'STRUCTURED_REVIEWED_DATA',
    HOMEPAGE_SUMMARIZATION: 'HOMEPAGE_SUMMARIZATION',
    PROMPT_REVIEW: 'PROMPT_REVIEW',
    REFLECTION: 'REFLECTION',
    SITE_CRAWL_PLAN: 'SITE_CRAWL_PLAN',
};
exports.templateMap = {
    [exports.templateTypes.HOMEPAGE_SUMMARIZATION]: contentSummarizationTemplate_1.HomePageSummarizationTemplate.create,
    [exports.templateTypes.STRUCTURED_REVIEWED_DATA]: structuredReviewedData_1.StructuredReviewedDataTemplate.create,
    [exports.templateTypes.STRUCTURED_DATA_EXTRACTION]: structuredDataExtractionTemplate_1.StructuredDataExtractionTemplate.create,
    [exports.templateTypes.CLASSIFICATION]: categoryClassificationTemplate_1.CategoryClassificationTemplate.create,
    [exports.templateTypes.PROMPT_REVIEW]: promptReviewTemplate_1.PromptReviewTemplate.create,
    [exports.templateTypes.REFLECTION]: reflectionTemplate_1.ReflectionTemplate.create,
    [exports.templateTypes.SITE_CRAWL_PLAN]: siteCrawlPlanTemplate_1.SiteCrawlPlanTemplate.create,
};
//# sourceMappingURL=templateRegistry.js.map