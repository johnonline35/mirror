import { BaseTemplate } from '../baseTemplate';
export declare class PromptReviewTemplate extends BaseTemplate {
    constructor(version?: string);
    static create(version?: string): PromptReviewTemplate;
}
