import { BaseTemplate } from '../baseTemplate';
export declare class CategoryClassificationTemplate extends BaseTemplate {
    constructor(version?: string);
    static create(version?: string): CategoryClassificationTemplate;
}
