import { ConfigService } from '@nestjs/config';
import { ChatCompletionTool as OpenAIChatCompletionTool } from 'openai/resources/chat';
import { ChatCompletionMessageParam, ChatCompletionFunctionCallOption } from 'openai/resources';
import { PrismaService } from '../../../common/utils/prisma/prisma.service';
import { LLM, LLMOptions } from '../../llm.interface';
export type ChatCompletionTool = OpenAIChatCompletionTool;
export { ChatCompletionMessageParam, ChatCompletionFunctionCallOption };
export declare class OpenAiService implements LLM {
    private configService;
    private prisma;
    private openai;
    private readonly logger;
    constructor(configService: ConfigService, prisma: PrismaService);
    adapt(prompt: string, options?: LLMOptions): Promise<string>;
    chatCompletion(messages: any[], options?: LLMOptions): Promise<string>;
    private logTokenUsage;
    private getCallerFunctionDetails;
}
