export type OpenAIModels = 'gpt-4o-2024-05-13' | 'gpt-4o-2024-08-06' | 'gpt-4o-mini-2024-07-18' | 'gpt-3.5-turbo-0125';
export type AnthropicModels = 'claude-3-opus-20240229' | 'claude-3-sonnet-20240229' | 'claude-3-haiku-20240307';
export type HuggingFaceModels = 'gpt-neo-2.7B';
export type GeminiModels = 'gemini-1' | 'gemini-1.5';
export type CohereModels = 'cohere-command-xlarge' | 'cohere-command-medium';
export type Models = OpenAIModels | AnthropicModels | HuggingFaceModels | GeminiModels | CohereModels;
