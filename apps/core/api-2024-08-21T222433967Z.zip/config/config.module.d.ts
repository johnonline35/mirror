export declare class ConfigModule {
}
