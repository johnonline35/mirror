import { Logger } from '@nestjs/common';
import { IWorkflowHandler } from '../workflow-handler.interface';
import { TaskDispatcherService } from '../../../task-dispatcher/task-dispatcher.service';
import { ITask } from '../../../interfaces/task.interface';
import { ParsePromptService } from '../../../common/utils/parsing/parse-prompt.service';
import { StructuredDataTaskResponse } from './structured-data-workflow.interface';
import { UrlExtractorService } from '../../../common/utils/parsing/url-extractor.service';
import { ConcurrentPageDataService } from '../../../common/utils/concurrency/concurrency-handler.service';
import { JsonExtractionService } from '../../../common/utils/json-extraction-from-text/json-extraction.service';
export declare class StructuredDataWorkflowHandler implements IWorkflowHandler {
    private readonly taskDispatcher;
    private readonly parsePromptService;
    private readonly urlExtractorService;
    private readonly concurrentPageDataService;
    private readonly jsonExtractionService;
    protected readonly logger: Logger;
    constructor(taskDispatcher: TaskDispatcherService, parsePromptService: ParsePromptService, urlExtractorService: UrlExtractorService, concurrentPageDataService: ConcurrentPageDataService, jsonExtractionService: JsonExtractionService);
    handle(task: ITask): Promise<StructuredDataTaskResponse>;
    private executeAgentConcurrently;
}
