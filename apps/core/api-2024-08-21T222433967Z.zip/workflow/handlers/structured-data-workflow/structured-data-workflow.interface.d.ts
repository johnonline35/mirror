export interface StructuredDataTaskResponse {
    success?: boolean;
    feedback?: any;
    resultData?: any;
}
