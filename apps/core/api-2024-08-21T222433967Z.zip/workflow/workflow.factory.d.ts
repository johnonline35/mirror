import { ITask } from '../interfaces/task.interface';
import { IWorkflowHandler } from './handlers/workflow-handler.interface';
import { StructuredDataWorkflowHandler } from './handlers/structured-data-workflow/structured-data-workflow.handler';
export declare class WorkflowFactory {
    private readonly structuredDataWorkflowHandler;
    private readonly logger;
    constructor(structuredDataWorkflowHandler: StructuredDataWorkflowHandler);
    getWorkflowHandler(task: ITask): IWorkflowHandler;
}
