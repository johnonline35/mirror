export declare class WorkflowModule {
}
