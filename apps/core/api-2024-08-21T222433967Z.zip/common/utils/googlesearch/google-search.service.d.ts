import { TaskComponentType, TaskComponents } from '../../../interfaces/task.interface';
export declare class GoogleSearchUtilityService implements TaskComponents {
    name: string;
    description: string;
    type: TaskComponentType;
    search(query: string): Promise<Array<{
        title: string;
        link: string;
    }>>;
}
