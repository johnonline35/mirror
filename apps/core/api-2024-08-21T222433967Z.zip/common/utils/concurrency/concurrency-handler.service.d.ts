export declare class ConcurrentPageDataService {
    private pLimit;
    constructor();
    private initPLimit;
    execute<T, R>(items: T[], concurrencyLimit: number, taskFn: (item: T) => Promise<R>): Promise<R[]>;
}
