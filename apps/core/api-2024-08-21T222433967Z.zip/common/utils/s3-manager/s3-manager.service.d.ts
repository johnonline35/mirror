import { S3Client } from '@aws-sdk/client-s3';
export declare class S3ManagerService {
    private s3Client;
    constructor(s3Client: S3Client);
    listBucketContents(bucket: string): Promise<string[]>;
}
