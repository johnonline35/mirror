export declare class S3ManagerModule {
}
