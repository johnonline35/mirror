"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UtilitiesModule = void 0;
const common_1 = require("@nestjs/common");
const cheerio_service_1 = require("./cheerio/cheerio.service");
const google_search_service_1 = require("./googlesearch/google-search.service");
const parse_prompt_service_1 = require("./parsing/parse-prompt.service");
const url_extractor_service_1 = require("./parsing/url-extractor.service");
const concurrency_handler_service_1 = require("./concurrency/concurrency-handler.service");
const json_to_csv_service_1 = require("./json-to-csv/json-to-csv.service");
const json_extraction_service_1 = require("./json-extraction-from-text/json-extraction.service");
let UtilitiesModule = class UtilitiesModule {
};
exports.UtilitiesModule = UtilitiesModule;
exports.UtilitiesModule = UtilitiesModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [
            cheerio_service_1.CheerioUtilityService,
            google_search_service_1.GoogleSearchUtilityService,
            parse_prompt_service_1.ParsePromptService,
            url_extractor_service_1.UrlExtractorService,
            concurrency_handler_service_1.ConcurrentPageDataService,
            json_to_csv_service_1.JsonToCsvService,
            json_extraction_service_1.JsonExtractionService,
        ],
        exports: [
            cheerio_service_1.CheerioUtilityService,
            google_search_service_1.GoogleSearchUtilityService,
            parse_prompt_service_1.ParsePromptService,
            url_extractor_service_1.UrlExtractorService,
            concurrency_handler_service_1.ConcurrentPageDataService,
            json_to_csv_service_1.JsonToCsvService,
            json_extraction_service_1.JsonExtractionService,
        ],
    })
], UtilitiesModule);
//# sourceMappingURL=utilities.module.js.map