"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryOperation = void 0;
const async_retry_1 = __importDefault(require("async-retry"));
class AuthenticationFailureError extends Error {
}
class InvalidRequestError extends Error {
}
function shouldBailOut(error) {
    return (error instanceof AuthenticationFailureError ||
        error instanceof InvalidRequestError ||
        error.message.includes('Invalid URL'));
}
async function retryOperation(operation, options) {
    return (0, async_retry_1.default)(async (bail, attemptNumber) => {
        try {
            return await operation();
        }
        catch (error) {
            if (options.logLevel === 'verbose') {
                console.log(`Attempt ${attemptNumber} failed with error: ${error.message}`);
            }
            else if (options.logLevel === 'error') {
                console.error(`Error on attempt ${attemptNumber}: ${error.message}`);
            }
            if (options.customErrorHandler) {
                options.customErrorHandler(error);
            }
            if (shouldBailOut(error)) {
                if (options.logLevel !== 'none') {
                    console.error('Bailing out due to fatal error:', error);
                }
                bail(error);
            }
            throw error;
        }
    }, options);
}
exports.retryOperation = retryOperation;
//# sourceMappingURL=retry.utility.js.map