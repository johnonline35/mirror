/// <reference types="cheerio" />
import { TaskComponentType, TaskComponents } from '../../../interfaces/task.interface';
import { ExtractedPageData } from '../../../tools/crawler/strategies/crawler-strategies/crawler-strategy.interface';
import { Page } from 'puppeteer';
export declare class CheerioUtilityService implements TaskComponents {
    name: string;
    description: string;
    type: TaskComponentType;
    private readonly logger;
    load(html: string): cheerio.Root;
    private extractAndCleanText;
    private extractCompletePage;
    extractPageData(page: Page, url: string): Promise<ExtractedPageData>;
}
