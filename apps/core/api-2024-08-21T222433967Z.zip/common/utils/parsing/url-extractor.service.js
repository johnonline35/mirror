"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var UrlExtractorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UrlExtractorService = void 0;
const common_1 = require("@nestjs/common");
let UrlExtractorService = UrlExtractorService_1 = class UrlExtractorService {
    constructor() {
        this.logger = new common_1.Logger(UrlExtractorService_1.name);
    }
    extractUrls(text) {
        try {
            if (typeof text !== 'string') {
                text = String(text);
            }
            const urlRegex = /https?:\/\/[^\s"]+/g;
            const urls = text.match(urlRegex) || [];
            const validUrls = Array.from(new Set(urls.filter((url) => this.isValidUrl(url))));
            return validUrls;
        }
        catch (error) {
            this.logger.error('Failed to extract URLs', error);
            return [];
        }
    }
    isValidUrl(url) {
        try {
            const parsedUrl = new URL(url);
            return parsedUrl.hostname.includes('.');
        }
        catch (e) {
            this.logger.warn(`Invalid URL detected: ${url}`, e);
            return false;
        }
    }
    extractDomainName(url) {
        try {
            const parsedUrl = new URL(url);
            const hostname = parsedUrl.hostname;
            if (hostname.match(/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/)) {
                return hostname;
            }
            if (hostname.match(/^\[[0-9a-fA-F:]+\]$/)) {
                return hostname;
            }
            const domainParts = hostname.split('.');
            const decodedHostname = hostname.startsWith('xn--')
                ? decodeURIComponent(hostname)
                : hostname;
            if (domainParts.length > 2) {
                return domainParts.slice(-2).join('.');
            }
            else {
                return decodedHostname;
            }
        }
        catch (error) {
            console.error('Invalid URL', error);
            return '';
        }
    }
};
exports.UrlExtractorService = UrlExtractorService;
exports.UrlExtractorService = UrlExtractorService = UrlExtractorService_1 = __decorate([
    (0, common_1.Injectable)()
], UrlExtractorService);
//# sourceMappingURL=url-extractor.service.js.map