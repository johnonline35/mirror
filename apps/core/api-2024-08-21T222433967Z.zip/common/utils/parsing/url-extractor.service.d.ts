export declare class UrlExtractorService {
    private readonly logger;
    extractUrls(text: any): string[];
    private isValidUrl;
    extractDomainName(url: string): string;
}
