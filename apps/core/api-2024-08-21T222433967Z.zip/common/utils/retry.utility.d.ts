import retry from 'async-retry';
export type RetryOptions = retry.Options & {
    logLevel?: 'none' | 'error' | 'verbose';
    customErrorHandler?: (error: Error) => void;
};
export declare function retryOperation<T>(operation: () => Promise<T>, options: RetryOptions): Promise<T>;
