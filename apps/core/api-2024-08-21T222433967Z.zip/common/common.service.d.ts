export declare class CommonService {
}
