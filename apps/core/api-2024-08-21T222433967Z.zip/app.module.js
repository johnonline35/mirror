"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const config_1 = require("@nestjs/config");
const app_controller_1 = require("./app.controller");
const crawler_module_1 = require("./tools/crawler/crawler.module");
const llm_module_1 = require("./llm/llm.module");
const utilities_module_1 = require("./common/utils/utilities.module");
const common_module_1 = require("./common/common.module");
const agents_module_1 = require("./agents/agents.module");
const task_dispatcher_module_1 = require("./task-dispatcher/task-dispatcher.module");
const workflow_module_1 = require("./workflow/workflow.module");
const job_manager_module_1 = require("./job-manager/job-manager.module");
const structured_data_module_1 = require("./structured-data/structured-data.module");
const tools_module_1 = require("./tools/tools.module");
const components_registry_module_1 = require("./components-registry/components-registry.module");
const s3_manager_module_1 = require("./common/utils/s3-manager/s3-manager.module");
const lambda_module_1 = require("./lambda/lambda.module");
const nestjs_graceful_shutdown_1 = require("nestjs-graceful-shutdown");
const prisma_service_1 = require("./common/utils/prisma/prisma.service");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
            }),
            s3_manager_module_1.S3ManagerModule,
            components_registry_module_1.ComponentsRegistryModule,
            utilities_module_1.UtilitiesModule,
            common_module_1.CommonModule,
            tools_module_1.ToolsModule,
            crawler_module_1.CrawlerModule,
            llm_module_1.LlmModule,
            agents_module_1.AgentsModule,
            workflow_module_1.WorkflowModule,
            task_dispatcher_module_1.TaskDispatcherModule,
            job_manager_module_1.JobManagerModule,
            structured_data_module_1.StructuredDataModule,
            lambda_module_1.LambdaModule,
            nestjs_graceful_shutdown_1.GracefulShutdownModule.forRoot({
                cleanup: async (a) => {
                    await a.get(prisma_service_1.PrismaService).$disconnect();
                },
            }),
        ],
        controllers: [app_controller_1.AppController],
        providers: [core_1.DiscoveryService],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map