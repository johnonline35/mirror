export declare class TaskDispatcherModule {
}
