"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const serverless_express_1 = require("@vendia/serverless-express");
const bootstrap_1 = require("./bootstrap");
const lambda_warmer_1 = __importDefault(require("lambda-warmer"));
let nestApp;
let server;
const handler = async (event, context, callback) => {
    if (!nestApp) {
        nestApp = await (0, bootstrap_1.bootstrap)(false, false);
    }
    if (await (0, lambda_warmer_1.default)(event))
        return 'warmed';
    if (!server) {
        await nestApp.init();
        const expressApp = nestApp.getHttpAdapter().getInstance();
        server = (0, serverless_express_1.configure)({ app: expressApp });
    }
    return server(event, context, callback);
};
exports.handler = handler;
//# sourceMappingURL=index.js.map