export declare class ComponentsRegistryModule {
}
