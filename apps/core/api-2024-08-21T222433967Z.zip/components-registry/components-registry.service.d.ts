import { ModuleRef } from '@nestjs/core';
import { TaskComponents, TaskComponentType } from '../interfaces/task.interface';
export declare class ComponentsRegistryService {
    private readonly moduleRef;
    private readonly logger;
    private readonly componentsRegistry;
    constructor(moduleRef: ModuleRef);
    getComponentsByType(componentType: TaskComponentType): TaskComponents[];
}
