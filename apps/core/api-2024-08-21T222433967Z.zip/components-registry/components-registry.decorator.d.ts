import { Provider } from '@nestjs/common';
import { TaskComponentType } from '../interfaces/task.interface';
export declare function TaskComponent(taskComponentType: TaskComponentType): (constructor: any) => void;
export declare function createTaskComponentSymbol(taskComponentType: TaskComponentType, typeName: string): string;
export declare const createTaskComponentRegistrySymbol: () => string;
export declare function getTaskComponentProviders(): Provider[];
