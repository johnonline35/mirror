"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTaskComponentProviders = exports.createTaskComponentRegistrySymbol = exports.createTaskComponentSymbol = exports.TaskComponent = void 0;
const registry = new Map();
function TaskComponent(taskComponentType) {
    return function (constructor) {
        registry.set(taskComponentType, constructor);
    };
}
exports.TaskComponent = TaskComponent;
function createTaskComponentSymbol(taskComponentType, typeName) {
    return `TASKCOMPONENT_${taskComponentType}_${typeName}`;
}
exports.createTaskComponentSymbol = createTaskComponentSymbol;
const createTaskComponentRegistrySymbol = () => `TASKCOMPONENT_REGISTRY`;
exports.createTaskComponentRegistrySymbol = createTaskComponentRegistrySymbol;
function getTaskComponentProviders() {
    const providers = [];
    const providerKeys = new Set();
    for (const [type, taskComponent] of registry.entries()) {
        const provide = createTaskComponentSymbol(type, taskComponent.name);
        providers.push({
            provide,
            useClass: taskComponent,
        });
        providerKeys.add(provide);
    }
    providers.push({
        provide: (0, exports.createTaskComponentRegistrySymbol)(),
        useValue: providerKeys,
    });
    return providers;
}
exports.getTaskComponentProviders = getTaskComponentProviders;
//# sourceMappingURL=components-registry.decorator.js.map