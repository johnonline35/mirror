"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComponentsRegistryModule = void 0;
const common_1 = require("@nestjs/common");
const components_registry_service_1 = require("./components-registry.service");
const core_1 = require("@nestjs/core");
const common_module_1 = require("../common/common.module");
const components_registry_decorator_1 = require("./components-registry.decorator");
const crawler_module_1 = require("../tools/crawler/crawler.module");
let ComponentsRegistryModule = class ComponentsRegistryModule {
};
exports.ComponentsRegistryModule = ComponentsRegistryModule;
exports.ComponentsRegistryModule = ComponentsRegistryModule = __decorate([
    (0, common_1.Module)({
        imports: [core_1.DiscoveryModule, common_module_1.CommonModule, crawler_module_1.CrawlerModule],
        providers: [components_registry_service_1.ComponentsRegistryService, ...(0, components_registry_decorator_1.getTaskComponentProviders)()],
        exports: [components_registry_service_1.ComponentsRegistryService],
    })
], ComponentsRegistryModule);
//# sourceMappingURL=components-registry.module.js.map