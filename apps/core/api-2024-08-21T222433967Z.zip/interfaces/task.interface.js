"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskComponentType = void 0;
var TaskComponentType;
(function (TaskComponentType) {
    TaskComponentType["TOOL"] = "tool";
    TaskComponentType["UTILITY"] = "utility";
})(TaskComponentType || (exports.TaskComponentType = TaskComponentType = {}));
//# sourceMappingURL=task.interface.js.map