"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bootstrap_1 = require("./bootstrap");
(0, bootstrap_1.bootstrap)(true).then(() => process.exit(0));
//# sourceMappingURL=openapi.js.map