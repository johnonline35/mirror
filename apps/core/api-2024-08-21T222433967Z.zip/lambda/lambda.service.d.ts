export declare class LambdaService {
    private lambdaClient;
    constructor();
    invokeLambda(functionName: string, payload: any): Promise<any>;
}
