export declare class LambdaModule {
}
