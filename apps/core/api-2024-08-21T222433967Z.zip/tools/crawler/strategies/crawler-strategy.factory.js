"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CrawlerStrategyFactory_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerStrategyFactory = void 0;
const common_1 = require("@nestjs/common");
const crawl_puppeteer_strategy_1 = require("./crawler-strategies/crawl-puppeteer/crawl-puppeteer.strategy");
let CrawlerStrategyFactory = CrawlerStrategyFactory_1 = class CrawlerStrategyFactory {
    constructor(crawlPuppeteerStrategy) {
        this.crawlPuppeteerStrategy = crawlPuppeteerStrategy;
        this.logger = new common_1.Logger(CrawlerStrategyFactory_1.name);
    }
    getStrategy(domainName) {
        switch (domainName) {
            case 'google.com':
                return this.crawlPuppeteerStrategy;
            default:
                return this.crawlPuppeteerStrategy;
        }
    }
};
exports.CrawlerStrategyFactory = CrawlerStrategyFactory;
exports.CrawlerStrategyFactory = CrawlerStrategyFactory = CrawlerStrategyFactory_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [crawl_puppeteer_strategy_1.CrawlPuppeteerStrategy])
], CrawlerStrategyFactory);
//# sourceMappingURL=crawler-strategy.factory.js.map