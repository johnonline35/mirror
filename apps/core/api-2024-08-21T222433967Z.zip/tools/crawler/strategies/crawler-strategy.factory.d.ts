import { CrawlPuppeteerStrategy } from './crawler-strategies/crawl-puppeteer/crawl-puppeteer.strategy';
import { ICrawlerStrategy } from './crawler-strategies/crawler-strategy.interface';
export declare class CrawlerStrategyFactory {
    private readonly crawlPuppeteerStrategy;
    private readonly logger;
    constructor(crawlPuppeteerStrategy: CrawlPuppeteerStrategy);
    getStrategy(domainName: string): ICrawlerStrategy;
}
