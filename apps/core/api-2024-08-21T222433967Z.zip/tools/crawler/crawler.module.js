"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerModule = void 0;
const common_1 = require("@nestjs/common");
const common_module_1 = require("../../common/common.module");
const crawler_service_1 = require("./crawler.service");
const llm_module_1 = require("../../llm/llm.module");
const crawler_strategy_factory_1 = require("./strategies/crawler-strategy.factory");
const crawl_puppeteer_strategy_1 = require("./strategies/crawler-strategies/crawl-puppeteer/crawl-puppeteer.strategy");
const lambda_module_1 = require("../../lambda/lambda.module");
let CrawlerModule = class CrawlerModule {
};
exports.CrawlerModule = CrawlerModule;
exports.CrawlerModule = CrawlerModule = __decorate([
    (0, common_1.Module)({
        imports: [common_module_1.CommonModule, llm_module_1.LlmModule, lambda_module_1.LambdaModule],
        providers: [crawler_service_1.CrawlerService, crawler_strategy_factory_1.CrawlerStrategyFactory, crawl_puppeteer_strategy_1.CrawlPuppeteerStrategy],
        exports: [crawler_service_1.CrawlerService, crawler_strategy_factory_1.CrawlerStrategyFactory, crawl_puppeteer_strategy_1.CrawlPuppeteerStrategy],
    })
], CrawlerModule);
//# sourceMappingURL=crawler.module.js.map