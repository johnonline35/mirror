"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CrawlerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerService = void 0;
const common_1 = require("@nestjs/common");
const crawler_strategy_factory_1 = require("./strategies/crawler-strategy.factory");
const task_interface_1 = require("../../interfaces/task.interface");
const components_registry_decorator_1 = require("../../components-registry/components-registry.decorator");
const url_extractor_service_1 = require("../../common/utils/parsing/url-extractor.service");
let CrawlerService = CrawlerService_1 = class CrawlerService {
    constructor(crawlerStrategyFactory, urlExtractorService) {
        this.crawlerStrategyFactory = crawlerStrategyFactory;
        this.urlExtractorService = urlExtractorService;
        this.name = 'Crawler Service';
        this.description = 'Crawls websites and does things like html extraction, image extraction, link extraction and anything else needed to get data from a website for further decision making and deeper continuous / recursive crawling';
        this.type = task_interface_1.TaskComponentType.TOOL;
        this.logger = new common_1.Logger(CrawlerService_1.name);
    }
    async execute(task, url) {
        const taskUrl = task.details.url;
        const strategy = this.getStrategy(taskUrl, url);
        return strategy.execute(task, url);
    }
    getStrategy(taskUrl, url) {
        if (url) {
            const domainName = this.urlExtractorService.extractDomainName(url);
            return this.crawlerStrategyFactory.getStrategy(domainName);
        }
        else {
            const domainName = this.urlExtractorService.extractDomainName(taskUrl);
            return this.crawlerStrategyFactory.getStrategy(domainName);
        }
    }
};
exports.CrawlerService = CrawlerService;
exports.CrawlerService = CrawlerService = CrawlerService_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, components_registry_decorator_1.TaskComponent)(task_interface_1.TaskComponentType.TOOL),
    __metadata("design:paramtypes", [crawler_strategy_factory_1.CrawlerStrategyFactory,
        url_extractor_service_1.UrlExtractorService])
], CrawlerService);
//# sourceMappingURL=crawler.service.js.map