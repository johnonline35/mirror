"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsModule = void 0;
const common_1 = require("@nestjs/common");
const utilities_module_1 = require("../common/utils/utilities.module");
const components_registry_module_1 = require("../components-registry/components-registry.module");
const common_module_1 = require("../common/common.module");
const crawler_module_1 = require("./crawler/crawler.module");
let ToolsModule = class ToolsModule {
};
exports.ToolsModule = ToolsModule;
exports.ToolsModule = ToolsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            crawler_module_1.CrawlerModule,
            utilities_module_1.UtilitiesModule,
            components_registry_module_1.ComponentsRegistryModule,
            common_module_1.CommonModule,
        ],
        exports: [crawler_module_1.CrawlerModule],
    })
], ToolsModule);
//# sourceMappingURL=tools.module.js.map