export declare class ToolsModule {
}
