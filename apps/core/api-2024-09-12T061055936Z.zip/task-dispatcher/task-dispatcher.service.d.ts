import { ITask } from '../interfaces/task.interface';
import { AgentType } from '../agents/common/agent-registry';
import { AgentsService } from '../agents/agents.service';
export declare class TaskDispatcherService {
    private readonly agentsService;
    private readonly logger;
    constructor(agentsService: AgentsService);
    dispatch(task: ITask, agentType: AgentType, additionalData?: any): Promise<any>;
    private getAgentForType;
}
