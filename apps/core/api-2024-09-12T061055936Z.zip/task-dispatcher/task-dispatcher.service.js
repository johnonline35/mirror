"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TaskDispatcherService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskDispatcherService = void 0;
const common_1 = require("@nestjs/common");
const agents_service_1 = require("../agents/agents.service");
let TaskDispatcherService = TaskDispatcherService_1 = class TaskDispatcherService {
    constructor(agentsService) {
        this.agentsService = agentsService;
        this.logger = new common_1.Logger(TaskDispatcherService_1.name);
    }
    async dispatch(task, agentType, additionalData) {
        try {
            const agent = this.getAgentForType(agentType);
            if (!agent) {
                throw new Error(`No suitable agent found for type ${agentType}`);
            }
            return await agent.execute(task, additionalData);
        }
        catch (error) {
            this.logger.error(`Error in dispatchTask: ${error.stack}`);
            throw error;
        }
    }
    getAgentForType(agentType) {
        this.logger.log(`Getting agent for type: ${agentType}`);
        const agent = this.agentsService.getAgent(agentType);
        if (!agent) {
            throw new Error(`Agent not found for type ${agentType}`);
        }
        return agent;
    }
};
exports.TaskDispatcherService = TaskDispatcherService;
exports.TaskDispatcherService = TaskDispatcherService = TaskDispatcherService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [agents_service_1.AgentsService])
], TaskDispatcherService);
//# sourceMappingURL=task-dispatcher.service.js.map