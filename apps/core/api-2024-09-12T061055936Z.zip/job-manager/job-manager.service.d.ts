import { PrismaService } from '../common/services/prisma/prisma.service';
import { ITask } from '../interfaces/task.interface';
import { WorkflowService } from '../workflow/workflow.service';
import { IJobManagerService } from './job-manager-service.interface';
import { S3ManagerService } from '../common/services/aws/s3-manager/s3-manager.service';
export declare class JobManagerService implements IJobManagerService {
    private prisma;
    private workflowService;
    private s3ManagerService;
    private readonly logger;
    constructor(prisma: PrismaService, workflowService: WorkflowService, s3ManagerService: S3ManagerService);
    createJob(task: ITask, clientId?: string): Promise<any>;
    executeJobInBackground(jobId: string, task: ITask): Promise<any>;
    updateJobStatus(jobId: string, status: string, s3Url?: any): Promise<any>;
    getJobStatus(jobId: string): Promise<any>;
    associateJobWithClient(jobId: string, clientId: string): Promise<void>;
}
