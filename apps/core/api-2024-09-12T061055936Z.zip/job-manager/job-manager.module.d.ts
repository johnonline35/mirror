export declare class JobManagerModule {
}
