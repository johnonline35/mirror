"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var JobManagerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobManagerService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/services/prisma/prisma.service");
const workflow_service_1 = require("../workflow/workflow.service");
const s3_manager_service_1 = require("../common/services/aws/s3-manager/s3-manager.service");
let JobManagerService = JobManagerService_1 = class JobManagerService {
    constructor(prisma, workflowService, s3ManagerService) {
        this.prisma = prisma;
        this.workflowService = workflowService;
        this.s3ManagerService = s3ManagerService;
        this.logger = new common_1.Logger(JobManagerService_1.name);
    }
    async createJob(task, clientId) {
        this.logger.log(`Creating job for task: ${JSON.stringify(task.details)}`);
        const data = {
            status: 'started',
            url: task.details.url,
        };
        const job = await this.prisma.job.create({
            data,
        });
        if (clientId) {
            await this.associateJobWithClient(job.jobId, clientId);
        }
        return { jobId: job.jobId };
    }
    async executeJobInBackground(jobId, task) {
        this.logger.log(`Starting executeJobInBackground with jobId:`, jobId);
        await this.updateJobStatus(jobId, 'in-progress');
        try {
            const result = await this.workflowService.handle(task);
            const bucketName = 'client-results-json';
            const key = `jobs/${jobId}/result.json`;
            const s3Url = await this.s3ManagerService.uploadToS3(bucketName, key, result);
            await this.updateJobStatus(jobId, 'completed', s3Url);
            return result;
        }
        catch (error) {
            this.logger.error(`Job execution failed for job ${jobId}:`, error);
            await this.updateJobStatus(jobId, 'failed');
            throw error;
        }
    }
    async updateJobStatus(jobId, status, s3Url) {
        this.logger.log(`Updating job status for ${jobId} to ${status}`);
        const dataToUpdate = {
            status,
            s3Url,
        };
        try {
            return await this.prisma.job.update({
                where: { jobId },
                data: dataToUpdate,
            });
        }
        catch (error) {
            this.logger.error(`Failed to update job status for ${jobId}`, error.stack);
            throw error;
        }
    }
    async getJobStatus(jobId) {
        return await this.prisma.job.findUnique({
            where: { jobId },
        });
    }
    async associateJobWithClient(jobId, clientId) {
        this.logger.log(`Associating job ${jobId} with client ${clientId}`);
        try {
            await this.prisma.job.update({
                where: { jobId },
                data: { clientId },
            });
            this.logger.log(`Successfully associated job ${jobId} with client ${clientId}`);
        }
        catch (error) {
            this.logger.error(`Failed to associate job ${jobId} with client ${clientId}`, error.stack);
            throw error;
        }
    }
};
exports.JobManagerService = JobManagerService;
exports.JobManagerService = JobManagerService = JobManagerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        workflow_service_1.WorkflowService,
        s3_manager_service_1.S3ManagerService])
], JobManagerService);
//# sourceMappingURL=job-manager.service.js.map