export declare function bootstrap(enableOpenApi: boolean, debugRequestsLogger?: boolean): Promise<import("@nestjs/common").INestApplication<any>>;
