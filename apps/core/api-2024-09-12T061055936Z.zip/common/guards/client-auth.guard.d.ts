import { CanActivate, ExecutionContext } from '@nestjs/common';
import { ClientService } from '../services/client/client.service';
export declare class ClientAuthGuard implements CanActivate {
    private readonly clientService;
    constructor(clientService: ClientService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
