"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientAuthGuard = void 0;
const common_1 = require("@nestjs/common");
const client_service_1 = require("../services/client/client.service");
let ClientAuthGuard = class ClientAuthGuard {
    constructor(clientService) {
        this.clientService = clientService;
    }
    async canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const authHeader = request.headers['authorization'];
        if (!authHeader || !authHeader.startsWith('Basic ')) {
            console.error('Missing or invalid authorization header.');
            throw new common_1.UnauthorizedException('Invalid authorization header');
        }
        const base64Credentials = authHeader.split(' ')[1];
        const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
        const [clientId, clientSecret] = credentials.split(':');
        if (!clientId || !clientSecret) {
            console.error('Missing clientId or clientSecret in the authorization header.');
            throw new common_1.UnauthorizedException('Invalid client credentials');
        }
        const isValid = await this.clientService.validateClient(clientId, clientSecret);
        if (!isValid) {
            console.error(`Authentication failed for client ID ${clientId}.`);
            throw new common_1.UnauthorizedException('Invalid client credentials');
        }
        return true;
    }
};
exports.ClientAuthGuard = ClientAuthGuard;
exports.ClientAuthGuard = ClientAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [client_service_1.ClientService])
], ClientAuthGuard);
//# sourceMappingURL=client-auth.guard.js.map