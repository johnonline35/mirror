import { ClientService } from './client.service';
import { CreateClientDto } from './dtos/create-client.dto';
export declare class ClientController {
    private readonly clientService;
    constructor(clientService: ClientService);
    createClient(createClientDto: CreateClientDto): Promise<{
        message: string;
        client: {
            id: number;
            clientId: string;
            clientSecret: string;
            lastLogin: Date;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
}
