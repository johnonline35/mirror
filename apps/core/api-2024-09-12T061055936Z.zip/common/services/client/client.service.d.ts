import { PrismaService } from '../prisma/prisma.service';
import { Client } from '@prisma/client';
export declare class ClientService {
    private readonly prisma;
    private readonly saltRounds;
    constructor(prisma: PrismaService);
    createClient(clientId: string, clientSecret: string): Promise<{
        id: number;
        clientId: string;
        clientSecret: string;
        lastLogin: Date;
        createdAt: Date;
        updatedAt: Date;
    }>;
    validateClient(clientId: string, clientSecret: string): Promise<boolean>;
    findClientById(clientId: string): Promise<Client | null>;
}
