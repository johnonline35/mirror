export declare class CreateClientDto {
    clientId: string;
    clientSecret: string;
}
