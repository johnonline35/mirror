export declare class ServicesModule {
}
