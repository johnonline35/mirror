export declare class AuthService {
    extractClientIdFromHeader(authHeader: string): string;
}
