"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
let AuthService = class AuthService {
    extractClientIdFromHeader(authHeader) {
        if (!authHeader || !authHeader.startsWith('Basic ')) {
            throw new common_1.UnauthorizedException('Invalid authorization header format');
        }
        const base64Credentials = authHeader.split(' ')[1];
        let credentials;
        try {
            credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
        }
        catch (error) {
            throw new common_1.UnauthorizedException('Invalid base64 encoding in authorization header');
        }
        const [clientId] = credentials.split(':');
        if (!clientId) {
            throw new common_1.UnauthorizedException('Missing clientId in authorization header');
        }
        return clientId;
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)()
], AuthService);
//# sourceMappingURL=auth.service.js.map