import { SQSClient } from '@aws-sdk/client-sqs';
export declare class SqsService {
    private readonly sqsClient;
    private readonly logger;
    constructor(sqsClient: SQSClient);
    sendMessage(queueUrl: string, messageBody: string): Promise<void>;
}
