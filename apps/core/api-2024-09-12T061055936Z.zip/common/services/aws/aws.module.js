"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AWSModule = void 0;
const common_1 = require("@nestjs/common");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const s3_manager_service_1 = require("../aws/s3-manager/s3-manager.service");
const sqs_service_1 = require("./sqs/sqs.service");
let AWSModule = class AWSModule {
};
exports.AWSModule = AWSModule;
exports.AWSModule = AWSModule = __decorate([
    (0, common_1.Module)({
        providers: [
            {
                provide: client_s3_1.S3Client,
                useValue: new client_s3_1.S3Client({ region: process.env.AWS_REGION || 'us-east-1' }),
            },
            {
                provide: client_sqs_1.SQSClient,
                useValue: new client_sqs_1.SQSClient({
                    region: process.env.AWS_REGION || 'us-east-1',
                }),
            },
            s3_manager_service_1.S3ManagerService,
            sqs_service_1.SqsService,
        ],
        exports: [s3_manager_service_1.S3ManagerService, sqs_service_1.SqsService],
    })
], AWSModule);
//# sourceMappingURL=aws.module.js.map