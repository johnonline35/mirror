export declare class AWSModule {
}
