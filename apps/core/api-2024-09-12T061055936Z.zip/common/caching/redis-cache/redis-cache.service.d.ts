import { Cache } from '@nestjs/cache-manager';
export declare class CachingService {
    private cacheManager;
    constructor(cacheManager: Cache);
    get(key: string): Promise<any>;
    set(key: string, value: any, ttl?: number): Promise<void>;
    del(key: string): Promise<void>;
}
