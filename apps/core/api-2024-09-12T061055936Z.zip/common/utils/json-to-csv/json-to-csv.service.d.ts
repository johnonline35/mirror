export declare class JsonToCsvService {
    convertJsonToCsv(jsonData: any): Promise<string>;
}
