"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var CheerioUtilityService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheerioUtilityService = void 0;
const common_1 = require("@nestjs/common");
const cheerio = __importStar(require("cheerio"));
const task_interface_1 = require("../../../interfaces/task.interface");
const components_registry_decorator_1 = require("../../../components-registry/components-registry.decorator");
let CheerioUtilityService = CheerioUtilityService_1 = class CheerioUtilityService {
    constructor() {
        this.name = 'CheerioUtility';
        this.description = 'Parses HTML content';
        this.type = task_interface_1.TaskComponentType.UTILITY;
        this.logger = new common_1.Logger(CheerioUtilityService_1.name);
    }
    load(html) {
        return cheerio.load(html);
    }
    extractAndCleanText($) {
        $('script, link[rel="stylesheet"], style, svg, path, meta, noscript, iframe, object, embed').remove();
        $('[style]').removeAttr('style');
        $('*')
            .filter((_, el) => !$(el).html().trim())
            .remove();
        function getTextWithSpacing(element) {
            let text = '';
            element.contents().each((_, el) => {
                const node = $(el);
                if (el.type === 'text') {
                    text += node.text();
                }
                else if (el.type === 'tag') {
                    text += ' ' + getTextWithSpacing(node) + ' ';
                }
            });
            return text;
        }
        let cleanedText = getTextWithSpacing($('body')).trim();
        cleanedText = cleanedText.replace(/\s+/g, ' ');
        return cleanedText;
    }
    extractCompletePage($, baseUrl) {
        const elements = [];
        function resolveUrl(url) {
            return new URL(url, baseUrl).href;
        }
        function traverse(element) {
            element.contents().each((_, el) => {
                const node = $(el);
                if (el.type === 'text') {
                    elements.push(node.text().trim());
                }
                else if (el.type === 'tag') {
                    const tagName = el.tagName.toLowerCase();
                    if ([
                        'a',
                        'img',
                        'script',
                        'style',
                        'link',
                        'h1',
                        'h2',
                        'h3',
                        'h4',
                        'h5',
                        'h6',
                    ].includes(tagName)) {
                        let info = '';
                        switch (tagName) {
                            case 'a':
                                const href = node.attr('href');
                                if (href) {
                                    info = `Link: ${resolveUrl(href)} (${node.text().trim()})`;
                                }
                                break;
                            case 'img':
                                const src = node.attr('src');
                                if (src) {
                                    info = `Image: ${resolveUrl(src)} (${node.attr('alt') || ''})`;
                                }
                                break;
                            case 'script':
                                const scriptSrc = node.attr('src');
                                if (scriptSrc) {
                                    info = `Script: ${resolveUrl(scriptSrc)}`;
                                }
                                break;
                            case 'link':
                                if (node.attr('rel') === 'stylesheet') {
                                    const linkHref = node.attr('href');
                                    if (linkHref) {
                                        info = `Stylesheet: ${resolveUrl(linkHref)}`;
                                    }
                                }
                                break;
                            case 'h1':
                            case 'h2':
                            case 'h3':
                            case 'h4':
                            case 'h5':
                            case 'h6':
                                info = `Heading (${tagName.toUpperCase()}): ${node.text().trim()}`;
                                break;
                        }
                        elements.push(info);
                    }
                    traverse(node);
                }
            });
        }
        traverse($('body'));
        return elements.filter(Boolean).join(' ');
    }
    async extractPageData(page, url) {
        const html = await page.content();
        const $ = cheerio.load(html);
        const baseUrl = url;
        const getBaseDomain = (url) => {
            const hostname = new URL(url).hostname;
            const parts = hostname.split('.').reverse();
            if (parts.length >= 2) {
                return parts[1] + '.' + parts[0];
            }
            return hostname;
        };
        const baseDomain = getBaseDomain(baseUrl);
        const cleanedText = this.extractAndCleanText($);
        const completePage = this.extractCompletePage($, baseUrl);
        const uniqueInternalLinks = new Set();
        const uniqueExternalLinks = new Set();
        const internalLinks = [];
        const externalLinks = [];
        const uniqueImageUrls = new Set();
        const imageUrls = [];
        const uniqueScriptUrls = new Set();
        const scriptUrls = [];
        const uniqueStylesheetUrls = new Set();
        const stylesheetUrls = [];
        const metaTags = {};
        const headings = {
            H1: [],
            H2: [],
            H3: [],
            H4: [],
            H5: [],
            H6: [],
        };
        $('a').each((_, el) => {
            const href = $(el).attr('href');
            const text = $(el).text().trim();
            if (href) {
                const resolvedUrl = new URL(href, baseUrl).href;
                const resolvedDomain = getBaseDomain(resolvedUrl);
                const linkData = { url: resolvedUrl, name: text || href };
                if (resolvedDomain === baseDomain) {
                    if (!uniqueInternalLinks.has(resolvedUrl)) {
                        uniqueInternalLinks.add(resolvedUrl);
                        internalLinks.push(linkData);
                    }
                }
                else {
                    if (!uniqueExternalLinks.has(resolvedUrl)) {
                        uniqueExternalLinks.add(resolvedUrl);
                        externalLinks.push(linkData);
                    }
                }
            }
        });
        $('img').each((_, el) => {
            const src = $(el).attr('src');
            const alt = $(el).attr('alt');
            const parentDivClass = $(el).closest('div').attr('class');
            if (src && !uniqueImageUrls.has(src)) {
                uniqueImageUrls.add(src);
                imageUrls.push({
                    url: new URL(src, baseUrl).href,
                    name: alt || parentDivClass || '',
                });
            }
        });
        $('meta').each((_, el) => {
            const name = $(el).attr('name') || $(el).attr('property');
            const content = $(el).attr('content');
            if (name && content) {
                metaTags[name] = content;
            }
        });
        const title = $('title').text().trim();
        Object.keys(headings).forEach((tag) => {
            $(tag).each((_, el) => {
                headings[tag].push($(el).text().trim());
            });
        });
        $('script').each((_, el) => {
            const src = $(el).attr('src');
            if (src) {
                const resolvedUrl = new URL(src, baseUrl).href;
                if (!uniqueScriptUrls.has(resolvedUrl)) {
                    uniqueScriptUrls.add(resolvedUrl);
                    scriptUrls.push(resolvedUrl);
                }
            }
        });
        $('link[rel="stylesheet"]').each((_, el) => {
            const href = $(el).attr('href');
            if (href) {
                const resolvedUrl = new URL(href, baseUrl).href;
                if (!uniqueStylesheetUrls.has(resolvedUrl)) {
                    uniqueStylesheetUrls.add(resolvedUrl);
                    stylesheetUrls.push(resolvedUrl);
                }
            }
        });
        this.logger.log(`Extracted data from URL`);
        const extractedPageData = {
            url,
            cleanedText,
            metaTags,
            title,
            headings,
            internalLinks,
            externalLinks,
            imageUrls,
            scriptUrls,
            stylesheetUrls,
            completePage,
        };
        return extractedPageData;
    }
    async extractPageDataFromHtml(html, url) {
        const $ = this.load(html);
        const baseUrl = url;
        const getBaseDomain = (url) => {
            const hostname = new URL(url).hostname;
            const parts = hostname.split('.').reverse();
            if (parts.length >= 2) {
                return parts[1] + '.' + parts[0];
            }
            return hostname;
        };
        const baseDomain = getBaseDomain(baseUrl);
        const cleanedText = this.extractAndCleanText($);
        const completePage = this.extractCompletePage($, baseUrl);
        const uniqueInternalLinks = new Set();
        const uniqueExternalLinks = new Set();
        const internalLinks = [];
        const externalLinks = [];
        const uniqueImageUrls = new Set();
        const imageUrls = [];
        const uniqueScriptUrls = new Set();
        const scriptUrls = [];
        const uniqueStylesheetUrls = new Set();
        const stylesheetUrls = [];
        const metaTags = {};
        const headings = {
            H1: [],
            H2: [],
            H3: [],
            H4: [],
            H5: [],
            H6: [],
        };
        $('a').each((_, el) => {
            const href = $(el).attr('href');
            const text = $(el).text().trim();
            if (href) {
                const resolvedUrl = new URL(href, baseUrl).href;
                const resolvedDomain = getBaseDomain(resolvedUrl);
                const linkData = { url: resolvedUrl, name: text || href };
                if (resolvedDomain === baseDomain) {
                    if (!uniqueInternalLinks.has(resolvedUrl)) {
                        uniqueInternalLinks.add(resolvedUrl);
                        internalLinks.push(linkData);
                    }
                }
                else {
                    if (!uniqueExternalLinks.has(resolvedUrl)) {
                        uniqueExternalLinks.add(resolvedUrl);
                        externalLinks.push(linkData);
                    }
                }
            }
        });
        $('img').each((_, el) => {
            const src = $(el).attr('src');
            const alt = $(el).attr('alt');
            const parentDivClass = $(el).closest('div').attr('class');
            if (src && !uniqueImageUrls.has(src)) {
                uniqueImageUrls.add(src);
                imageUrls.push({
                    url: new URL(src, baseUrl).href,
                    name: alt || parentDivClass || '',
                });
            }
        });
        $('meta').each((_, el) => {
            const name = $(el).attr('name') || $(el).attr('property');
            const content = $(el).attr('content');
            if (name && content) {
                metaTags[name] = content;
            }
        });
        const title = $('title').text().trim();
        Object.keys(headings).forEach((tag) => {
            $(tag).each((_, el) => {
                headings[tag].push($(el).text().trim());
            });
        });
        $('script').each((_, el) => {
            const src = $(el).attr('src');
            if (src) {
                const resolvedUrl = new URL(src, baseUrl).href;
                if (!uniqueScriptUrls.has(resolvedUrl)) {
                    uniqueScriptUrls.add(resolvedUrl);
                    scriptUrls.push(resolvedUrl);
                }
            }
        });
        $('link[rel="stylesheet"]').each((_, el) => {
            const href = $(el).attr('href');
            if (href) {
                const resolvedUrl = new URL(href, baseUrl).href;
                if (!uniqueStylesheetUrls.has(resolvedUrl)) {
                    uniqueStylesheetUrls.add(resolvedUrl);
                    stylesheetUrls.push(resolvedUrl);
                }
            }
        });
        this.logger.log(`Extracted data from URL: ${url}`);
        const extractedPageData = {
            url,
            cleanedText,
            metaTags,
            title,
            headings,
            internalLinks,
            externalLinks,
            imageUrls,
            scriptUrls,
            stylesheetUrls,
            completePage,
        };
        return extractedPageData;
    }
};
exports.CheerioUtilityService = CheerioUtilityService;
exports.CheerioUtilityService = CheerioUtilityService = CheerioUtilityService_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, components_registry_decorator_1.TaskComponent)(task_interface_1.TaskComponentType.UTILITY)
], CheerioUtilityService);
//# sourceMappingURL=cheerio.service.js.map