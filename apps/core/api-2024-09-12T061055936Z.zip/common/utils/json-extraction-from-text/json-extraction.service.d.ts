export declare class JsonExtractionService {
    extractValidJson(text: string): object[];
}
