export declare class UtilitiesModule {
}
