import { ValidatePromptContext } from '../../../agents/types/validate-prompt/validate-prompt.interface';
export declare class ParsePromptService {
    private readonly logger;
    parsePromptReview(context: ValidatePromptContext): {
        success?: boolean;
        feedback?: string;
    };
}
