export declare class ConcurrentPageDataService {
    execute<T, R>(items: T[], concurrencyLimit: number, taskFn: (item: T) => Promise<R>): Promise<(R | null)[]>;
}
