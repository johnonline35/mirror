"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bootstrap = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const body_parser_1 = __importDefault(require("body-parser"));
const helmet_1 = __importDefault(require("helmet"));
const app_module_1 = require("./app.module");
const quiet_logger_1 = require("./quiet-logger");
async function bootstrap(enableOpenApi, debugRequestsLogger) {
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        cors: true,
        snapshot: true,
        logger: new quiet_logger_1.QuietStartupLogger(true),
        bodyParser: false,
    });
    const rawBodyBuffer = (req, res, buffer, encoding) => {
        if (!req.headers['stripe-signature']) {
            return;
        }
        if (buffer && buffer.length) {
            req.rawBody = buffer.toString(encoding || 'utf8');
        }
    };
    app.use(body_parser_1.default.urlencoded({ verify: rawBodyBuffer, extended: true }));
    app.use(body_parser_1.default.json({ limit: 2000000, verify: rawBodyBuffer }));
    if (debugRequestsLogger) {
        app.use((request, response, next) => {
            const { ip, method, path: url } = request;
            const userAgent = request.get('user-agent') || '';
            response.on('close', () => {
                const { statusCode } = response;
                const contentLength = response.get('content-length');
                common_1.Logger.log(`${method} ${url} ${statusCode} ${contentLength} - ${userAgent} ${ip}`);
            });
            next();
        });
    }
    app.use((0, helmet_1.default)({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: `* 'unsafe-inline' 'unsafe-eval' 'unsafe-dynamic'`,
            },
        },
    }));
    if (enableOpenApi) {
        console.log('enableOpenApi is enabled but code isnt here', enableOpenApi);
    }
    app.useGlobalPipes(new common_1.ValidationPipe({ whitelist: true, transform: true }));
    return app;
}
exports.bootstrap = bootstrap;
//# sourceMappingURL=bootstrap.js.map