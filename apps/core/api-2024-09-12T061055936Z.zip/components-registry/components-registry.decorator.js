"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskComponent = exports.TASK_COMPONENT_KEY = void 0;
const common_1 = require("@nestjs/common");
exports.TASK_COMPONENT_KEY = 'TASK_COMPONENT_KEY';
function TaskComponent(taskComponentType) {
    return (0, common_1.SetMetadata)(exports.TASK_COMPONENT_KEY, taskComponentType);
}
exports.TaskComponent = TaskComponent;
//# sourceMappingURL=components-registry.decorator.js.map