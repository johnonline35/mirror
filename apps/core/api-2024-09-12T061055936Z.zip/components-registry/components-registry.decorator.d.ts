import { TaskComponentType } from '../interfaces/task.interface';
export declare const TASK_COMPONENT_KEY = "TASK_COMPONENT_KEY";
export declare function TaskComponent(taskComponentType: TaskComponentType): import("@nestjs/common").CustomDecorator<string>;
