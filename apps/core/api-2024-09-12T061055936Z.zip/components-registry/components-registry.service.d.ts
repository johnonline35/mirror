import { DiscoveryService, Reflector } from '@nestjs/core';
import { TaskComponentType, TaskComponents } from '../interfaces/task.interface';
export declare class ComponentsRegistryService {
    private readonly discoveryService;
    private readonly reflector;
    private readonly logger;
    private readonly componentsRegistry;
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    private registerComponents;
    getComponentsByType(componentType: TaskComponentType): TaskComponents[];
}
