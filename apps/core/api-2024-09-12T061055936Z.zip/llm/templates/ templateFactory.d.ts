import { BaseTemplate } from './baseTemplate';
import { templateTypes } from './templateRegistry';
export declare class TemplateFactory {
    static createTemplate(type: (typeof templateTypes)[keyof typeof templateTypes], version?: string): BaseTemplate;
}
