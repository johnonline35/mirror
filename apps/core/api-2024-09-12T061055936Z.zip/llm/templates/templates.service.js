"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplatesService = void 0;
const common_1 = require("@nestjs/common");
const _templateFactory_1 = require("./ templateFactory");
const templateRegistry_1 = require("./templateRegistry");
let TemplatesService = class TemplatesService {
    getClassificationTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.CLASSIFICATION, version);
    }
    getSummarizationTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.HOMEPAGE_SUMMARIZATION, version);
    }
    getPromptReviewTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.PROMPT_REVIEW, version);
    }
    getSiteCrawlPlanTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.SITE_CRAWL_PLAN, version);
    }
    getReflectionTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.REFLECTION, version);
    }
    getDataExtractionTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.STRUCTURED_DATA_EXTRACTION, version);
    }
    getDataReviewTemplate(version) {
        return this.getTemplate(templateRegistry_1.templateTypes.STRUCTURED_REVIEWED_DATA, version);
    }
    getTemplate(type, version) {
        return _templateFactory_1.TemplateFactory.createTemplate(type, version);
    }
};
exports.TemplatesService = TemplatesService;
exports.TemplatesService = TemplatesService = __decorate([
    (0, common_1.Injectable)()
], TemplatesService);
//# sourceMappingURL=templates.service.js.map