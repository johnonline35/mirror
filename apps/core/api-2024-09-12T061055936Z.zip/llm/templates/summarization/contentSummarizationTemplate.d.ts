import { BaseTemplate } from '../baseTemplate';
export declare class HomePageSummarizationTemplate extends BaseTemplate {
    constructor(version?: string);
    static create(version?: string): HomePageSummarizationTemplate;
}
