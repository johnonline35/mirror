import { BaseTemplate } from './baseTemplate';
export declare const templateTypes: {
    readonly CLASSIFICATION: "CLASSIFICATION";
    readonly STRUCTURED_DATA_EXTRACTION: "STRUCTURED_DATA_EXTRACTION";
    readonly STRUCTURED_REVIEWED_DATA: "STRUCTURED_REVIEWED_DATA";
    readonly HOMEPAGE_SUMMARIZATION: "HOMEPAGE_SUMMARIZATION";
    readonly PROMPT_REVIEW: "PROMPT_REVIEW";
    readonly REFLECTION: "REFLECTION";
    readonly SITE_CRAWL_PLAN: "SITE_CRAWL_PLAN";
};
type TemplateType = (typeof templateTypes)[keyof typeof templateTypes];
type TemplateConstructor = (version?: string) => BaseTemplate;
export declare const templateMap: Record<TemplateType, TemplateConstructor>;
export {};
