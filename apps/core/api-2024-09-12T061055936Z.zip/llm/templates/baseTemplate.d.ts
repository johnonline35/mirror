export declare abstract class BaseTemplate {
    protected template: string;
    protected version: string;
    constructor(template: string, version: string);
    private registerHelpers;
    render(data: Record<string, any>): string;
    validate(): boolean;
    getVersion(): string;
}
