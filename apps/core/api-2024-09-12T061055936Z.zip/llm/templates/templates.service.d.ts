import { BaseTemplate } from './baseTemplate';
export declare class TemplatesService {
    getClassificationTemplate(version: string): BaseTemplate;
    getSummarizationTemplate(version: string): BaseTemplate;
    getPromptReviewTemplate(version: string): BaseTemplate;
    getSiteCrawlPlanTemplate(version: string): BaseTemplate;
    getReflectionTemplate(version: string): BaseTemplate;
    getDataExtractionTemplate(version: string): BaseTemplate;
    getDataReviewTemplate(version: string): BaseTemplate;
    private getTemplate;
}
