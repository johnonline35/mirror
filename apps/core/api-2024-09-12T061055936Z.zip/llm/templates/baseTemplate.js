"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseTemplate = void 0;
const handlebars_1 = __importDefault(require("handlebars"));
class BaseTemplate {
    constructor(template, version) {
        this.template = template;
        this.version = version;
        this.registerHelpers();
    }
    registerHelpers() {
        if (!handlebars_1.default.helpers.json) {
            handlebars_1.default.registerHelper('json', function (context) {
                return JSON.stringify(context, null, 2);
            });
        }
    }
    render(data) {
        const compiledTemplate = handlebars_1.default.compile(this.template);
        return compiledTemplate(data);
    }
    validate() {
        return true;
    }
    getVersion() {
        return this.version;
    }
}
exports.BaseTemplate = BaseTemplate;
//# sourceMappingURL=baseTemplate.js.map