"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createLLMOptions = void 0;
const MAX_TOKENS = {
    'gpt-3.5-turbo-0125': 4096,
    'gpt-4o-mini-2024-07-18': 4096,
    'gpt-4o-2024-05-13': 4096,
    'gpt-4o-2024-08-06': 4096,
    'claude-3-opus-20240229': 9000,
    'claude-3-sonnet-20240229': 9000,
    'claude-3-haiku-20240307': 9000,
    'gpt-neo-2.7B': 2048,
    'gemini-1': 4096,
    'gemini-1.5': 4096,
    'cohere-command-xlarge': 2048,
    'cohere-command-medium': 2048,
};
function createLLMOptions(options) {
    if (options.model) {
        const maxTokensLimit = MAX_TOKENS[options.model];
        if (options.maxTokens !== undefined &&
            (options.maxTokens < 1 || options.maxTokens > maxTokensLimit)) {
            throw new Error(`maxTokens for model ${options.model} must be between 1 and ${maxTokensLimit}`);
        }
    }
    else {
        const defaultMaxTokensLimit = 2048;
        if (options.maxTokens !== undefined &&
            (options.maxTokens < 1 || options.maxTokens > defaultMaxTokensLimit)) {
            throw new Error(`maxTokens must be between 1 and ${defaultMaxTokensLimit}`);
        }
    }
    if (options.temperature !== undefined &&
        (options.temperature < 0 || options.temperature > 1)) {
        throw new Error('temperature must be between 0 and 1');
    }
    if (options.topP !== undefined && (options.topP < 0 || options.topP > 1)) {
        throw new Error('topP must be between 0 and 1');
    }
    if (options.frequencyPenalty !== undefined &&
        (options.frequencyPenalty < -2.0 || options.frequencyPenalty > 2.0)) {
        throw new Error('frequencyPenalty must be between -2.0 and 2.0');
    }
    if (options.presencePenalty !== undefined &&
        (options.presencePenalty < -2.0 || options.presencePenalty > 2.0)) {
        throw new Error('presencePenalty must be between -2.0 and 2.0');
    }
    if (options.topLogprobs !== undefined &&
        (options.topLogprobs < 0 || options.topLogprobs > 20)) {
        throw new Error('topLogprobs must be between 0 and 20');
    }
    if (options.stream === undefined) {
        options.stream = false;
    }
    return options;
}
exports.createLLMOptions = createLLMOptions;
//# sourceMappingURL=llm.interface.js.map