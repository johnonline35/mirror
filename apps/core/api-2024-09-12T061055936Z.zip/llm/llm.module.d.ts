export declare class LlmModule {
}
