"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var OpenAiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAiService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const openai_1 = __importDefault(require("openai"));
const prisma_service_1 = require("../../../common/services/prisma/prisma.service");
let OpenAiService = OpenAiService_1 = class OpenAiService {
    constructor(configService, prisma) {
        this.configService = configService;
        this.prisma = prisma;
        this.logger = new common_1.Logger(OpenAiService_1.name);
        this.openai = new openai_1.default({
            apiKey: this.configService.get('OPENAI_API_KEY'),
        });
    }
    adapt(prompt, options) {
        return this.chatCompletion([{ role: 'user', content: prompt }], options);
    }
    async chatCompletion(messages, options = {}) {
        const callerDetails = this.getCallerFunctionDetails();
        const startTime = Date.now();
        try {
            const response = await this.openai.chat.completions.create({
                model: options.model,
                messages,
                max_tokens: options.maxTokens,
                temperature: options.temperature,
                top_p: options.topP,
                frequency_penalty: options.frequencyPenalty,
                presence_penalty: options.presencePenalty,
                stop: options.stopSequences,
            });
            const duration = Date.now() - startTime;
            const tokenUsage = response.usage;
            this.logger.log(JSON.stringify({
                message: 'Token usage',
                caller: callerDetails,
                tokenUsage: tokenUsage,
                options: options,
                duration: `${duration}ms`,
            }));
            await this.logTokenUsage(messages, response.choices[0].message.content, tokenUsage, callerDetails, options, duration);
            return response.choices[0].message.content.trim();
        }
        catch (error) {
            this.logger.error({
                message: 'Error calling OpenAI API',
                caller: callerDetails,
                error: error.message,
            });
            throw error;
        }
    }
    async logTokenUsage(messages, response, tokenUsage, caller, options, duration) {
        try {
            await this.prisma.tokenUsage.create({
                data: {
                    request_tokens: tokenUsage.prompt_tokens,
                    response_tokens: tokenUsage.completion_tokens,
                    total_tokens: tokenUsage.total_tokens,
                    request_content: JSON.stringify(messages),
                    response_content: response,
                    endpoint: caller,
                    options: JSON.stringify(options),
                    duration: duration,
                },
            });
        }
        catch (error) {
            this.logger.error({
                message: 'Failed to log token usage',
                error: error.message,
            });
        }
    }
    getCallerFunctionDetails() {
        var _a;
        const error = new Error();
        const stack = (_a = error.stack) === null || _a === void 0 ? void 0 : _a.split('\n');
        const callerStackLine = stack ? stack[3] : '';
        const match = callerStackLine.match(/at\s+([^(]+)\s+\(([^:]+):(\d+):(\d+)\)/);
        if (match && match.length > 1) {
            return `Function: ${match[1].trim()}, File: ${match[2]}, Line: ${match[3]}, Column: ${match[4]}`;
        }
        return `unknown, Full Stack: ${error.stack}`;
    }
};
exports.OpenAiService = OpenAiService;
exports.OpenAiService = OpenAiService = OpenAiService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService])
], OpenAiService);
//# sourceMappingURL=openai.service.js.map