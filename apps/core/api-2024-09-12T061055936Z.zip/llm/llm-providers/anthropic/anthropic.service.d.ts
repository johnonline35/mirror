import { ConfigService } from '@nestjs/config';
import { LLM, LLMOptions } from '../../llm.interface';
export declare class ClaudeService implements LLM {
    private configService;
    private anthropic;
    constructor(configService: ConfigService);
    adapt(prompt: string, options?: LLMOptions): void;
    chatCompletion(messages: any[], options?: LLMOptions): Promise<string>;
}
