import { Models } from './llm.models';
import { ChatCompletionTool } from './llm-providers/openai/openai.service';
export interface LLM {
    chatCompletion(messages: any[], options?: LLMOptions): Promise<string>;
    adapt(prompt: string, options?: LLMOptions): any;
}
type Temperature = 0 | 0.1 | 0.2 | 0.3 | 0.4 | 0.5 | 0.6 | 0.7 | 0.8 | 0.9 | 1;
export interface LLMOptions {
    model?: Models;
    maxTokens?: number;
    temperature?: Temperature;
    topP?: number;
    frequencyPenalty?: number;
    presencePenalty?: number;
    stopSequences?: string[];
    stream?: boolean;
    system?: string;
    responseFormat?: 'json_object' | 'text';
    logprobs?: boolean;
    topLogprobs?: number;
    user?: string;
    toolChoice?: 'none' | 'auto' | 'required';
    tools?: Array<ChatCompletionTool>;
    functionCall?: 'none' | 'auto' | {
        name: string;
    };
    seed?: number | null;
}
export declare function createLLMOptions(options: LLMOptions): LLMOptions;
export {};
