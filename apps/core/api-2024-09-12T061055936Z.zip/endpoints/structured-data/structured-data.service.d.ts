import { JobManagerService } from '../../job-manager/job-manager.service';
import { StructuredDataDto } from './dtos/structured-data.dto';
import { ComponentsRegistryService } from '../../components-registry/components-registry.service';
import { SqsService } from '../../common/services/aws/sqs/sqs.service';
export declare class StructuredDataService {
    private readonly jobManagerService;
    private readonly componentsRegistryService;
    private readonly sqsService;
    constructor(jobManagerService: JobManagerService, componentsRegistryService: ComponentsRegistryService, sqsService: SqsService);
    startJobAsync(requestDto: StructuredDataDto, clientId?: string): Promise<{
        jobId: any;
    }>;
    private stringifySchema;
}
