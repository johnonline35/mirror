export declare class StructuredDataModule {
}
