"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StructuredDataController = void 0;
const common_1 = require("@nestjs/common");
const structured_data_service_1 = require("./structured-data.service");
const structured_data_dto_1 = require("./dtos/structured-data.dto");
const client_auth_guard_1 = require("../../common/guards/client-auth.guard");
const client_service_1 = require("../../common/services/client/client.service");
const job_manager_service_1 = require("../../job-manager/job-manager.service");
const auth_service_1 = require("../../common/services/auth/auth.service");
let StructuredDataController = class StructuredDataController {
    constructor(structuredDataService, clientService, jobManagerService, authService) {
        this.structuredDataService = structuredDataService;
        this.clientService = clientService;
        this.jobManagerService = jobManagerService;
        this.authService = authService;
    }
    async handle(requestDto, authHeader) {
        const clientId = this.authService.extractClientIdFromHeader(authHeader);
        const client = await this.clientService.findClientById(clientId);
        if (!client) {
            throw new common_1.NotFoundException(`Client with ID ${clientId} not found.`);
        }
        const { jobId } = await this.structuredDataService.startJobAsync(requestDto, clientId);
        return { jobId };
    }
    async getJobStatus(jobId, authHeader) {
        const clientId = this.authService.extractClientIdFromHeader(authHeader);
        const job = await this.jobManagerService.getJobStatus(jobId);
        if (!job) {
            throw new common_1.NotFoundException(`Job with ID ${jobId} not found.`);
        }
        if (job.clientId !== clientId) {
            throw new common_1.ForbiddenException('Unauthorized access to job status');
        }
        return {
            jobId: job.jobId,
            status: job.status,
            result: job.status === 'completed' ? job.s3Url : null,
        };
    }
};
exports.StructuredDataController = StructuredDataController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [structured_data_dto_1.StructuredDataDto, String]),
    __metadata("design:returntype", Promise)
], StructuredDataController.prototype, "handle", null);
__decorate([
    (0, common_1.Get)('status/:jobId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('jobId')),
    __param(1, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StructuredDataController.prototype, "getJobStatus", null);
exports.StructuredDataController = StructuredDataController = __decorate([
    (0, common_1.Controller)('structured-data'),
    (0, common_1.UseGuards)(client_auth_guard_1.ClientAuthGuard),
    __metadata("design:paramtypes", [structured_data_service_1.StructuredDataService,
        client_service_1.ClientService,
        job_manager_service_1.JobManagerService,
        auth_service_1.AuthService])
], StructuredDataController);
//# sourceMappingURL=structured-data.controller.js.map