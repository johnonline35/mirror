import { StructuredDataService } from './structured-data.service';
import { StructuredDataDto } from './dtos/structured-data.dto';
import { ClientService } from '../../common/services/client/client.service';
import { JobManagerService } from '../../job-manager/job-manager.service';
import { AuthService } from '../../common/services/auth/auth.service';
export declare class StructuredDataController {
    private readonly structuredDataService;
    private readonly clientService;
    private readonly jobManagerService;
    private readonly authService;
    constructor(structuredDataService: StructuredDataService, clientService: ClientService, jobManagerService: JobManagerService, authService: AuthService);
    handle(requestDto: StructuredDataDto, authHeader: string): Promise<{
        jobId: any;
    }>;
    getJobStatus(jobId: string, authHeader: string): Promise<{
        jobId: any;
        status: any;
        result: any;
    }>;
}
