export declare class StructuredDataDto {
    prompt: string;
    url: string;
    schema: any;
}
