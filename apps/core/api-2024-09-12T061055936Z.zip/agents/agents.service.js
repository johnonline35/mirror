"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AgentsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentsService = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const agent_registry_1 = require("./common/agent-registry");
let AgentsService = AgentsService_1 = class AgentsService {
    constructor(discoveryService, reflector) {
        this.discoveryService = discoveryService;
        this.reflector = reflector;
        this.agentMap = new Map();
        this.logger = new common_1.Logger(AgentsService_1.name);
    }
    onModuleInit() {
        this.registerAgents();
    }
    registerAgents() {
        const providers = this.discoveryService.getProviders();
        this.logger.debug(`Discovered ${providers.length} providers`);
        providers.forEach((wrapper) => {
            const { instance } = wrapper;
            if (!instance || !instance.constructor) {
                this.logger.debug(`Instance or constructor missing for provider: ${wrapper.name}`);
                return;
            }
            if (instance && instance.constructor) {
                const agentType = this.reflector.get(agent_registry_1.AGENT_METADATA_KEY, instance.constructor);
                if (agentType) {
                    this.logger.debug(`Registering agent: ${agent_registry_1.AgentType[agentType]}`);
                    this.agentMap.set(agentType, instance);
                }
                else {
                    this.logger.debug(`No agent type found for instance: ${instance.constructor.name}`);
                }
            }
        });
        this.logger.debug(`Registered agents: ${Array.from(this.agentMap.entries())
            .map(([key, value]) => `${agent_registry_1.AgentType[key]}: ${value.constructor.name}`)
            .join(', ')}`);
    }
    getAgent(agentType) {
        const agent = this.agentMap.get(agentType);
        if (!agent) {
            this.logger.warn(`Agent not found for type: ${agent_registry_1.AgentType[agentType]}`);
        }
        return agent;
    }
    getAllAgents() {
        return new Map(this.agentMap);
    }
};
exports.AgentsService = AgentsService;
exports.AgentsService = AgentsService = AgentsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.DiscoveryService,
        core_1.Reflector])
], AgentsService);
//# sourceMappingURL=agents.service.js.map