import { OnModuleInit } from '@nestjs/common';
import { DiscoveryService, Reflector } from '@nestjs/core';
import { AgentType } from './common/agent-registry';
import { IAgent } from './common/agent.interface';
export declare class AgentsService implements OnModuleInit {
    private readonly discoveryService;
    private readonly reflector;
    private agentMap;
    private readonly logger;
    constructor(discoveryService: DiscoveryService, reflector: Reflector);
    onModuleInit(): void;
    private registerAgents;
    getAgent(agentType: AgentType): IAgent;
    getAllAgents(): Map<AgentType, IAgent>;
}
