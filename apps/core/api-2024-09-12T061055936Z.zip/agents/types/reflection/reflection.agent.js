"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ReflectionAgent_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReflectionAgent = void 0;
const common_1 = require("@nestjs/common");
const agent_state_1 = require("../../common/agent-state");
const agent_registry_1 = require("../../common/agent-registry");
const templates_service_1 = require("../../../llm/templates/templates.service");
const openai_service_1 = require("../../../llm/llm-providers/openai/openai.service");
let ReflectionAgent = ReflectionAgent_1 = class ReflectionAgent {
    constructor(templatesService, openAiService) {
        this.templatesService = templatesService;
        this.openAiService = openAiService;
        this.logger = new common_1.Logger(ReflectionAgent_1.name);
    }
    async initializeAgent(task) {
        this.state = new agent_state_1.AgentState(task);
        this.state.setInitialized();
        this.logger.log(`Initializing ValidatePromptAgent with task: ${JSON.stringify(task)}`);
    }
    async execute(task, initialPlan, homepageData) {
        this.initializeAgent(task);
        this.logger.log(`Executing: ${JSON.stringify(task)}`);
        try {
            const reflectionPlanTemplate = this.templatesService.getReflectionTemplate('1.0');
            console.log({
                task: task,
                initialPlan: initialPlan,
                homepageData: homepageData,
            });
            const reflectionPlan = reflectionPlanTemplate.render({
                task: task,
                initialPlan: initialPlan,
                homepageData: homepageData,
            });
            console.log(`Reflection plan template post render: ${reflectionPlan}`);
            const llmOptions = {
                model: 'gpt-4o-mini-2024-07-18',
                maxTokens: 1000,
                temperature: 1,
            };
            const reflection = await this.openAiService.adapt(reflectionPlan, llmOptions);
            this.state.context.reflection = reflection;
            this.state.setExecuted();
            return this.state.context.reflection;
        }
        catch (error) {
            this.handleError(error, this.state.context);
            throw error;
        }
        finally {
            if (this.state) {
                this.state.resetState();
            }
        }
    }
    async handleError(error, context) {
        this.state.setError(error);
        this.logger.error(`Error occurred while processing task ${JSON.stringify(context)}`, error.stack);
    }
};
exports.ReflectionAgent = ReflectionAgent;
exports.ReflectionAgent = ReflectionAgent = ReflectionAgent_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, agent_registry_1.RegisterAgent)(agent_registry_1.AgentType.ReflectionAgent),
    __metadata("design:paramtypes", [templates_service_1.TemplatesService,
        openai_service_1.OpenAiService])
], ReflectionAgent);
//# sourceMappingURL=reflection.agent.js.map