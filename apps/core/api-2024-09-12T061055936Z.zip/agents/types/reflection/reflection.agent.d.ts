import { Logger } from '@nestjs/common';
import { AgentState } from '../../common/agent-state';
import { ITask } from '../../../interfaces/task.interface';
import { IAgent } from '../../common/agent.interface';
import { TemplatesService } from '../../../llm/templates/templates.service';
import { OpenAiService } from '../../../llm/llm-providers/openai/openai.service';
import { ReflectionContext } from './reflection.interface';
export declare class ReflectionAgent implements IAgent {
    private readonly templatesService;
    private readonly openAiService;
    state: AgentState<ReflectionContext & ITask>;
    protected readonly logger: Logger;
    constructor(templatesService: TemplatesService, openAiService: OpenAiService);
    private initializeAgent;
    execute(task: ITask, initialPlan: any, homepageData: any): Promise<ReflectionContext>;
    handleError(error: Error, context: ReflectionContext & ITask): Promise<void>;
}
