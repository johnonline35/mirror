export interface ReflectionContext<T = any> {
    reflection?: T;
}
