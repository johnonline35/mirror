export interface ExtractedPageDataContext<T = any> {
    url?: string;
    extractedPageDataJson?: T;
}
