import { Logger } from '@nestjs/common';
import { AgentState } from '../../common/agent-state';
import { ITask } from '../../../interfaces/task.interface';
import { IAgent } from '../../common/agent.interface';
import { CrawlPageContext } from './crawl-page.interface';
import { CrawlerService } from '../../../tools/crawler/crawler.service';
import { CheerioUtilityService } from '../../../common/utils/cheerio/cheerio.service';
export declare class CrawlPageAgent implements IAgent {
    private readonly crawlerService;
    private readonly cheerioUtilityService;
    state: AgentState<CrawlPageContext & ITask>;
    protected readonly logger: Logger;
    constructor(crawlerService: CrawlerService, cheerioUtilityService: CheerioUtilityService);
    private initializeAgent;
    execute(task: ITask, url: string): Promise<CrawlPageContext>;
    handleError(error: Error, context: CrawlPageContext & ITask): Promise<void>;
}
