export interface CrawlPageContext<T = any> {
    individualPageDataObject?: T;
}
