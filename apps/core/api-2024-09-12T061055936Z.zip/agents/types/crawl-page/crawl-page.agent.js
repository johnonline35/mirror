"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CrawlPageAgent_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlPageAgent = void 0;
const common_1 = require("@nestjs/common");
const agent_state_1 = require("../../common/agent-state");
const agent_registry_1 = require("../../common/agent-registry");
const crawler_service_1 = require("../../../tools/crawler/crawler.service");
const cheerio_service_1 = require("../../../common/utils/cheerio/cheerio.service");
let CrawlPageAgent = CrawlPageAgent_1 = class CrawlPageAgent {
    constructor(crawlerService, cheerioUtilityService) {
        this.crawlerService = crawlerService;
        this.cheerioUtilityService = cheerioUtilityService;
        this.logger = new common_1.Logger(CrawlPageAgent_1.name);
    }
    async initializeAgent(task) {
        this.state = new agent_state_1.AgentState(task);
        this.state.setInitialized();
        this.logger.log(`Initializing CrawlPageAgent`);
    }
    async execute(task, url) {
        await this.initializeAgent(task);
        this.logger.log(`Executing: ${JSON.stringify(task)}`);
        try {
            const finalUrl = url || task.details.url;
            const rawPageHtml = await this.crawlerService.execute(task, url);
            const parsedHtml = await this.cheerioUtilityService.extractPageDataFromHtml(rawPageHtml, finalUrl);
            this.state.context.individualPageDataObject =
                parsedHtml;
            this.state.setExecuted();
            return this.state.context.individualPageDataObject;
        }
        catch (error) {
            await this.handleError(error, this.state.context);
            throw error;
        }
        finally {
            if (this.state) {
                this.state.resetState();
            }
        }
    }
    async handleError(error, context) {
        this.state.setError(error);
        this.logger.error(`Error occurred while processing task ${JSON.stringify(context)}`, error.stack);
    }
};
exports.CrawlPageAgent = CrawlPageAgent;
exports.CrawlPageAgent = CrawlPageAgent = CrawlPageAgent_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, agent_registry_1.RegisterAgent)(agent_registry_1.AgentType.CrawlPageAgent),
    __metadata("design:paramtypes", [crawler_service_1.CrawlerService,
        cheerio_service_1.CheerioUtilityService])
], CrawlPageAgent);
//# sourceMappingURL=crawl-page.agent.js.map