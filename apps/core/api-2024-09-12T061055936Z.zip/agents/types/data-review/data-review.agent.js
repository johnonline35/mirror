"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DataReviewAgent_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataReviewAgent = void 0;
const common_1 = require("@nestjs/common");
const agent_state_1 = require("../../common/agent-state");
const agent_registry_1 = require("../../common/agent-registry");
const templates_service_1 = require("../../../llm/templates/templates.service");
const openai_service_1 = require("../../../llm/llm-providers/openai/openai.service");
let DataReviewAgent = DataReviewAgent_1 = class DataReviewAgent {
    constructor(templatesService, openAiService) {
        this.templatesService = templatesService;
        this.openAiService = openAiService;
        this.logger = new common_1.Logger(DataReviewAgent_1.name);
    }
    async initializeAgent(task) {
        this.state = new agent_state_1.AgentState(task);
        this.state.setInitialized();
        this.logger.log(`Initializing DataReviewAgent}`);
    }
    async execute(task, processedPagesData) {
        this.initializeAgent(task);
        this.logger.log(`Processed Pages Data: ${JSON.stringify(processedPagesData)}`);
        try {
            const dataReviewTemplate = this.templatesService.getDataReviewTemplate('2.0');
            const dataReviewPrompt = dataReviewTemplate.render({
                task: task,
                processedPagesData: processedPagesData,
            });
            console.log(`Rendered prompt: ${dataReviewPrompt}`);
            const llmOptions = {
                model: 'gpt-4o-2024-05-13',
                maxTokens: 2000,
                temperature: 0.3,
            };
            const llmResponseString = await this.openAiService.adapt(dataReviewPrompt, llmOptions);
            console.log('processedData in form of schema:', llmResponseString);
            this.state.context.processedData =
                llmResponseString;
            this.state.setExecuted();
            return this.state.context.processedData;
        }
        catch (error) {
            this.handleError(error, this.state.context);
            throw error;
        }
        finally {
            if (this.state) {
                this.state.resetState();
            }
        }
    }
    async handleError(error, context) {
        this.state.setError(error);
        this.logger.error(`Error occurred while processing task ${JSON.stringify(context)}`, error.stack);
    }
};
exports.DataReviewAgent = DataReviewAgent;
exports.DataReviewAgent = DataReviewAgent = DataReviewAgent_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, agent_registry_1.RegisterAgent)(agent_registry_1.AgentType.DataReviewAgent),
    __metadata("design:paramtypes", [templates_service_1.TemplatesService,
        openai_service_1.OpenAiService])
], DataReviewAgent);
//# sourceMappingURL=data-review.agent.js.map