export interface ReviewedDataContext<T = any> {
    processedData?: T;
}
