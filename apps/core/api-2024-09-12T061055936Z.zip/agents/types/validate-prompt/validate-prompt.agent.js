"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ValidatePromptAgent_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidatePromptAgent = void 0;
const common_1 = require("@nestjs/common");
const agent_state_1 = require("../../common/agent-state");
const agent_registry_1 = require("../../common/agent-registry");
const templates_service_1 = require("../../../llm/templates/templates.service");
const openai_service_1 = require("../../../llm/llm-providers/openai/openai.service");
let ValidatePromptAgent = ValidatePromptAgent_1 = class ValidatePromptAgent {
    constructor(templatesService, openAiService) {
        this.templatesService = templatesService;
        this.openAiService = openAiService;
        this.logger = new common_1.Logger(ValidatePromptAgent_1.name);
    }
    async initializeAgent(task) {
        this.state = new agent_state_1.AgentState(task);
        this.state.setInitialized();
        this.logger.log(`Initializing ValidatePromptAgent with task: ${JSON.stringify(task)}`);
    }
    async execute(task) {
        this.initializeAgent(task);
        if (!this.state.initialized) {
            throw new Error('Agent not initialized');
        }
        this.logger.log(`Executing: ${JSON.stringify(task)}`);
        try {
            const promptReviewTemplate = this.templatesService.getPromptReviewTemplate('1.0');
            const taskPrompt = promptReviewTemplate.render({
                task: task,
            });
            console.log(`Rendered prompt: ${taskPrompt}`);
            const llmOptions = {
                model: 'gpt-4o-mini-2024-07-18',
                maxTokens: 500,
                temperature: 0.3,
            };
            const promptReview = await this.openAiService.adapt(taskPrompt, llmOptions);
            console.log(`Received prompt review from LLM: ${JSON.stringify(promptReview)}`);
            this.state.context.promptReview = promptReview;
            this.state.setExecuted();
            return this.state.context;
        }
        catch (error) {
            this.handleError(error, this.state.context);
            throw error;
        }
        finally {
            if (this.state) {
                this.state.resetState();
            }
        }
    }
    async handleError(error, context) {
        this.state.setError(error);
        this.logger.error(`Error occurred while processing task ${JSON.stringify(context)}`, error.stack);
    }
};
exports.ValidatePromptAgent = ValidatePromptAgent;
exports.ValidatePromptAgent = ValidatePromptAgent = ValidatePromptAgent_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, agent_registry_1.RegisterAgent)(agent_registry_1.AgentType.ValidatePromptAgent),
    __metadata("design:paramtypes", [templates_service_1.TemplatesService,
        openai_service_1.OpenAiService])
], ValidatePromptAgent);
//# sourceMappingURL=validate-prompt.agent.js.map