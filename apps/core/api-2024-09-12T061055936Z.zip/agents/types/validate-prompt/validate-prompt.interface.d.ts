export interface ValidatePromptContext {
    promptReview?: string;
}
