export declare enum AgentType {
    CrawlPageAgent = "CRAWL_PAGE_AGENT",
    CrawlSitePlanningAgent = "CRAWL_SITE_PLANNING_AGENT",
    DataExtractionAndInferenceAgent = "DATA_EXTRACTION_AND_INFERENCE_AGENT",
    DataReviewAgent = "DATA_REVIEW_AGENT",
    ReflectionAgent = "REFLECTION_AGENT",
    ValidatePromptAgent = "VALIDATE_PROMPT_AGENT"
}
export declare const AGENT_METADATA_KEY = "AGENT_METADATA_KEY";
export declare const RegisterAgent: (agentType: AgentType) => import("@nestjs/common").CustomDecorator<string>;
