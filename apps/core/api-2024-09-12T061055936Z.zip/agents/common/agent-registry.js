"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterAgent = exports.AGENT_METADATA_KEY = exports.AgentType = void 0;
const common_1 = require("@nestjs/common");
var AgentType;
(function (AgentType) {
    AgentType["CrawlPageAgent"] = "CRAWL_PAGE_AGENT";
    AgentType["CrawlSitePlanningAgent"] = "CRAWL_SITE_PLANNING_AGENT";
    AgentType["DataExtractionAndInferenceAgent"] = "DATA_EXTRACTION_AND_INFERENCE_AGENT";
    AgentType["DataReviewAgent"] = "DATA_REVIEW_AGENT";
    AgentType["ReflectionAgent"] = "REFLECTION_AGENT";
    AgentType["ValidatePromptAgent"] = "VALIDATE_PROMPT_AGENT";
})(AgentType || (exports.AgentType = AgentType = {}));
exports.AGENT_METADATA_KEY = 'AGENT_METADATA_KEY';
const RegisterAgent = (agentType) => (0, common_1.SetMetadata)(exports.AGENT_METADATA_KEY, agentType);
exports.RegisterAgent = RegisterAgent;
//# sourceMappingURL=agent-registry.js.map