export declare class AgentState<TContext> {
    context: TContext;
    private _initialized;
    private _executed;
    private _error;
    constructor(context: TContext);
    get initialized(): boolean;
    get executed(): boolean;
    get error(): Error | null;
    setInitialized(): void;
    setExecuted(): void;
    setError(error: Error): void;
    clearError(): void;
    resetState(): void;
}
