"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentState = void 0;
class AgentState {
    constructor(context) {
        this.context = context;
        this._initialized = false;
        this._executed = false;
        this._error = null;
    }
    get initialized() {
        return this._initialized;
    }
    get executed() {
        return this._executed;
    }
    get error() {
        return this._error;
    }
    setInitialized() {
        this._initialized = true;
    }
    setExecuted() {
        this._executed = true;
    }
    setError(error) {
        this._error = error;
    }
    clearError() {
        this._error = null;
    }
    resetState() {
        this._initialized = false;
        this._executed = false;
        this._error = null;
    }
}
exports.AgentState = AgentState;
//# sourceMappingURL=agent-state.js.map