import { CrawlerStrategyFactory } from './strategies/crawler-strategy.factory';
import { ITask, TaskComponentType } from '../../interfaces/task.interface';
import { ITool } from '../tools.interface';
import { UrlExtractorService } from '../../common/utils/parsing/url-extractor.service';
export declare class CrawlerService implements ITool<ITask> {
    private readonly crawlerStrategyFactory;
    private readonly urlExtractorService;
    name: string;
    description: string;
    type: TaskComponentType;
    private readonly logger;
    constructor(crawlerStrategyFactory: CrawlerStrategyFactory, urlExtractorService: UrlExtractorService);
    execute(task: ITask, url?: string): Promise<any>;
    private getStrategy;
}
