"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CrawlPuppeteerStrategy_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlPuppeteerStrategy = void 0;
const common_1 = require("@nestjs/common");
const lambda_service_1 = require("../../../../../lambda/lambda.service");
let CrawlPuppeteerStrategy = CrawlPuppeteerStrategy_1 = class CrawlPuppeteerStrategy {
    constructor(lambdaService) {
        this.lambdaService = lambdaService;
        this.logger = new common_1.Logger(CrawlPuppeteerStrategy_1.name);
    }
    async execute(task, url) {
        this.logger.log('Executing task:', JSON.stringify(task));
        const targetUrl = url || task.details.url;
        const html = this.crawlUrl(targetUrl);
        return html;
    }
    async crawlUrl(url) {
        this.logger.log(`Starting to crawl URL: ${url}`);
        try {
            const html = await this.crawlUrlWithLambda(url);
            return html;
        }
        catch (error) {
            this.logger.error(`Crawl failed: ${error.stack}`);
            throw error;
        }
    }
    async crawlUrlWithLambda(url) {
        try {
            const result = await this.lambdaService.invokeLambda(`PuppeteerApiStaging-AnyCatchallHTTPLambda-EJUtt6mngdvz`, { url });
            const resultSnippet = result.html.substring(0, 200);
            console.log('resultSnippet:', resultSnippet);
            return result.html;
        }
        catch (error) {
            this.logger.error(`Failed to fetch HTML from Lambda for URL: ${url}. Error: ${error.message}`);
            throw error;
        }
    }
};
exports.CrawlPuppeteerStrategy = CrawlPuppeteerStrategy;
exports.CrawlPuppeteerStrategy = CrawlPuppeteerStrategy = CrawlPuppeteerStrategy_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [lambda_service_1.LambdaService])
], CrawlPuppeteerStrategy);
//# sourceMappingURL=crawl-puppeteer.strategy.js.map