import { ITask } from '../../../../../interfaces/task.interface';
import { ICrawlerStrategy } from '../crawler-strategy.interface';
import { LambdaService } from '../../../../../lambda/lambda.service';
export declare class CrawlPuppeteerStrategy implements ICrawlerStrategy {
    private lambdaService;
    private readonly logger;
    constructor(lambdaService: LambdaService);
    execute(task: ITask, url?: string): Promise<string>;
    private crawlUrl;
    private crawlUrlWithLambda;
}
