export declare class CrawlerModule {
}
