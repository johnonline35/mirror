import { ITask } from '../../interfaces/task.interface';
import { AgentType } from '../../agents/common/agent-registry';
import { TaskDispatcherService } from '../../task-dispatcher/task-dispatcher.service';
import { ConcurrentPageDataService } from '../../common/utils/concurrency/concurrency-handler.service';
export declare class ConcurrentAgentExecutionService {
    private readonly taskDispatcher;
    private readonly concurrentPageDataService;
    constructor(taskDispatcher: TaskDispatcherService, concurrentPageDataService: ConcurrentPageDataService);
    executeAgentConcurrently<TInput, TOutput>(inputs: TInput[], task: ITask, agentType: AgentType, concurrencyLimit: number): Promise<TOutput[]>;
}
