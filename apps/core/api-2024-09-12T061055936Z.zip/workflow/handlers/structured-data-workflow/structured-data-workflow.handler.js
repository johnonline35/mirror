"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StructuredDataWorkflowHandler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StructuredDataWorkflowHandler = void 0;
const common_1 = require("@nestjs/common");
const task_dispatcher_service_1 = require("../../../task-dispatcher/task-dispatcher.service");
const agent_registry_1 = require("../../../agents/common/agent-registry");
const parse_prompt_service_1 = require("../../../common/utils/parsing/parse-prompt.service");
const url_extractor_service_1 = require("../../../common/utils/parsing/url-extractor.service");
const concurrency_handler_service_1 = require("../../../common/utils/concurrency/concurrency-handler.service");
const json_extraction_service_1 = require("../../../common/utils/json-extraction-from-text/json-extraction.service");
let StructuredDataWorkflowHandler = StructuredDataWorkflowHandler_1 = class StructuredDataWorkflowHandler {
    constructor(taskDispatcher, parsePromptService, urlExtractorService, concurrentPageDataService, jsonExtractionService) {
        this.taskDispatcher = taskDispatcher;
        this.parsePromptService = parsePromptService;
        this.urlExtractorService = urlExtractorService;
        this.concurrentPageDataService = concurrentPageDataService;
        this.jsonExtractionService = jsonExtractionService;
        this.logger = new common_1.Logger(StructuredDataWorkflowHandler_1.name);
    }
    async handle(task) {
        try {
            this.logger.log(`Handling workflow structured data extraction: ${JSON.stringify(task)}`);
            const promptReview = await this.taskDispatcher.dispatch(task, agent_registry_1.AgentType.ValidatePromptAgent);
            const canCompleteTask = this.parsePromptService.parsePromptReview(promptReview);
            if (canCompleteTask.success) {
                this.logger.log('Task can be successfully completed:', JSON.stringify(task));
                const homepageData = await this.taskDispatcher.dispatch(task, agent_registry_1.AgentType.CrawlPageAgent);
                const siteCrawlPlan = await this.taskDispatcher.dispatch(task, agent_registry_1.AgentType.CrawlSitePlanningAgent, homepageData);
                console.log('siteCrawlPlan', siteCrawlPlan);
                const urls = this.urlExtractorService.extractUrls(siteCrawlPlan.plan);
                console.log('urls', urls);
                const shortenedUrls = urls.slice(0, 5);
                const extractedPagesData = await this.executeAgentConcurrently(shortenedUrls, task, agent_registry_1.AgentType.CrawlPageAgent, 10);
                extractedPagesData.unshift(homepageData);
                console.log('extractedPagesData:');
                extractedPagesData.forEach((data, index) => {
                    console.log(`Result ${index + 1}:`, data);
                });
                const llmProcessedPagesData = await this.executeAgentConcurrently(extractedPagesData, task, agent_registry_1.AgentType.DataExtractionAndInferenceAgent, 5);
                llmProcessedPagesData.forEach((data, index) => {
                    console.log(`processedPagesData object ${index + 1}:`, data);
                });
                const llmFinalExtractedAndProcessedData = await this.taskDispatcher.dispatch(task, agent_registry_1.AgentType.DataReviewAgent, llmProcessedPagesData);
                console.log('processedData:', llmFinalExtractedAndProcessedData);
                const resultJson = this.jsonExtractionService.extractValidJson(llmFinalExtractedAndProcessedData);
                console.log('************final json************', JSON.stringify(resultJson));
                return {
                    success: true,
                    feedback: canCompleteTask.feedback,
                    resultData: resultJson,
                    urlsVisited: shortenedUrls,
                };
            }
            else {
                this.logger.warn(`Feedback: ${canCompleteTask.feedback}`);
                return {
                    success: false,
                    feedback: canCompleteTask.feedback,
                    resultData: [],
                };
            }
        }
        catch (error) {
            this.logger.error('Error handling structured data extraction:', error);
            throw new Error(`Workflow processing failed: ${error.message}`);
        }
    }
    async executeAgentConcurrently(inputs, task, agentType, concurrencyLimit) {
        const taskFn = (input) => this.taskDispatcher.dispatch(task, agentType, input);
        return this.concurrentPageDataService.execute(inputs, concurrencyLimit, taskFn);
    }
};
exports.StructuredDataWorkflowHandler = StructuredDataWorkflowHandler;
exports.StructuredDataWorkflowHandler = StructuredDataWorkflowHandler = StructuredDataWorkflowHandler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [task_dispatcher_service_1.TaskDispatcherService,
        parse_prompt_service_1.ParsePromptService,
        url_extractor_service_1.UrlExtractorService,
        concurrency_handler_service_1.ConcurrentPageDataService,
        json_extraction_service_1.JsonExtractionService])
], StructuredDataWorkflowHandler);
//# sourceMappingURL=structured-data-workflow.handler.js.map