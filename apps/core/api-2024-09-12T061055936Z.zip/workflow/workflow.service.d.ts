import { Logger } from '@nestjs/common';
import { WorkflowFactory } from './workflow.factory';
import { ITask } from '../interfaces/task.interface';
export declare class WorkflowService {
    private readonly workflowFactory;
    protected readonly logger: Logger;
    constructor(workflowFactory: WorkflowFactory);
    handle(task: ITask): Promise<any>;
}
