export declare class ProxyModule {
}
