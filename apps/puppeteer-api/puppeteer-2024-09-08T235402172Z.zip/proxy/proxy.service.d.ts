import { ConfigService } from '@nestjs/config';
export declare class ProxyService {
    private readonly configService;
    constructor(configService: ConfigService);
    getProxyConfig(): {
        server: any;
        credentials: {
            username: any;
            password: any;
            priority: any;
        };
    };
}
