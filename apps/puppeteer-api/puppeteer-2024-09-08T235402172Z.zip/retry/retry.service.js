"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var RetryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetryService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const async_retry_1 = __importDefault(require("async-retry"));
class AuthenticationFailureError extends Error {
}
class InvalidRequestError extends Error {
}
let RetryService = RetryService_1 = class RetryService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(RetryService_1.name);
    }
    shouldBailOut(error) {
        return (error instanceof AuthenticationFailureError ||
            error instanceof InvalidRequestError ||
            error.message.includes('Invalid URL'));
    }
    async retry(operation) {
        const options = this.configService.get('retryOptions');
        if (!options) {
            throw new Error('Retry options not found in configuration');
        }
        return (0, async_retry_1.default)(async (bail, attemptNumber) => {
            try {
                return await operation();
            }
            catch (error) {
                if (options.logLevel === 'verbose') {
                    this.logger.log(`Attempt ${attemptNumber} failed with error: ${error.message}`);
                }
                else if (options.logLevel === 'error') {
                    this.logger.error(`Error on attempt ${attemptNumber}: ${error.message}`);
                }
                if (options.customErrorHandler) {
                    options.customErrorHandler(error);
                }
                if (this.shouldBailOut(error)) {
                    if (options.logLevel !== 'none') {
                        this.logger.error('Bailing out due to fatal error:', error);
                    }
                    bail(error);
                }
                throw error;
            }
        }, options);
    }
};
exports.RetryService = RetryService;
exports.RetryService = RetryService = RetryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], RetryService);
//# sourceMappingURL=retry.service.js.map