import { ConfigService } from '@nestjs/config';
import retry from 'async-retry';
export type RetryOptions = retry.Options & {
    logLevel?: 'none' | 'error' | 'verbose';
    customErrorHandler?: (error: Error) => void;
};
export declare class RetryService {
    private readonly configService;
    private readonly logger;
    constructor(configService: ConfigService);
    private shouldBailOut;
    retry<T>(operation: () => Promise<T>): Promise<T>;
}
