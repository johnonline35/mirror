export declare class RetryModule {
}
