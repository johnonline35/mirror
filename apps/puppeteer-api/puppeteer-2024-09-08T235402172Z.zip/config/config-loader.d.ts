export declare function loadConfig(): any;
