export declare class PuppeteerModule {
}
