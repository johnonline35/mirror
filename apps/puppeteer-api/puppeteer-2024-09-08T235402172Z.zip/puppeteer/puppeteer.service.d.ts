import { BrowserService } from '../browser/browser.service';
import { ProxyService } from '../proxy/proxy.service';
import { RetryService } from '../retry/retry.service';
export declare class PuppeteerService {
    private readonly retryService;
    private readonly browserService;
    private readonly proxyService;
    private readonly logger;
    constructor(retryService: RetryService, browserService: BrowserService, proxyService: ProxyService);
    runPuppeteer(url: string): Promise<string>;
    private fetchPageContent;
    private setupPage;
    private scrollPage;
}
