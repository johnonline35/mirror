"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PuppeteerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PuppeteerService = void 0;
const common_1 = require("@nestjs/common");
const browser_service_1 = require("../browser/browser.service");
const proxy_service_1 = require("../proxy/proxy.service");
const retry_service_1 = require("../retry/retry.service");
let PuppeteerService = PuppeteerService_1 = class PuppeteerService {
    constructor(retryService, browserService, proxyService) {
        this.retryService = retryService;
        this.browserService = browserService;
        this.proxyService = proxyService;
        this.logger = new common_1.Logger(PuppeteerService_1.name);
    }
    async runPuppeteer(url) {
        return this.retryService.retry(() => this.fetchPageContent(url));
    }
    async fetchPageContent(url) {
        const browser = await this.browserService.launchBrowser();
        const page = await this.setupPage(browser);
        await page.goto(url, { waitUntil: 'networkidle2' });
        await this.scrollPage(page);
        const html = await page.content();
        await this.browserService.closeBrowser(browser);
        return html;
    }
    async setupPage(browser) {
        const page = await browser.newPage();
        const { credentials } = this.proxyService.getProxyConfig();
        await page.authenticate(credentials);
        return page;
    }
    async scrollPage(page) {
        let scrolls = 0;
        while (scrolls < 10) {
            await page.evaluate(() => window.scrollBy(0, window.innerHeight));
            await new Promise((resolve) => setTimeout(resolve, 500));
            scrolls++;
        }
    }
};
exports.PuppeteerService = PuppeteerService;
exports.PuppeteerService = PuppeteerService = PuppeteerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [retry_service_1.RetryService,
        browser_service_1.BrowserService,
        proxy_service_1.ProxyService])
], PuppeteerService);
//# sourceMappingURL=puppeteer.service.js.map