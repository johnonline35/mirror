export declare class BrowserModule {
}
