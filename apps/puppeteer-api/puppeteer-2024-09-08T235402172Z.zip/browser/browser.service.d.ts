import { ProxyService } from '../proxy/proxy.service';
import { Browser, Page } from 'puppeteer-core';
export { Browser, Page };
export declare class BrowserService {
    private readonly proxyService;
    private readonly logger;
    constructor(proxyService: ProxyService);
    launchBrowser(): Promise<Browser>;
    closeBrowser(browser: Browser): Promise<void>;
}
