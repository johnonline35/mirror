"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var BrowserService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrowserService = exports.Page = exports.Browser = void 0;
const common_1 = require("@nestjs/common");
const puppeteer_extra_1 = __importDefault(require("puppeteer-extra"));
const puppeteer_extra_plugin_stealth_1 = __importDefault(require("puppeteer-extra-plugin-stealth"));
const chromium_1 = __importDefault(require("@sparticuz/chromium"));
const proxy_service_1 = require("../proxy/proxy.service");
const puppeteer_core_1 = require("puppeteer-core");
Object.defineProperty(exports, "Browser", { enumerable: true, get: function () { return puppeteer_core_1.Browser; } });
Object.defineProperty(exports, "Page", { enumerable: true, get: function () { return puppeteer_core_1.Page; } });
let BrowserService = BrowserService_1 = class BrowserService {
    constructor(proxyService) {
        this.proxyService = proxyService;
        this.logger = new common_1.Logger(BrowserService_1.name);
        puppeteer_extra_1.default.use((0, puppeteer_extra_plugin_stealth_1.default)());
    }
    async launchBrowser() {
        const { server } = this.proxyService.getProxyConfig();
        const browser = (await puppeteer_extra_1.default.launch({
            args: [`--proxy-server=http://${server}`, ...chromium_1.default.args],
            defaultViewport: chromium_1.default.defaultViewport,
            executablePath: await chromium_1.default.executablePath(),
            headless: 'shell',
            ignoreHTTPSErrors: true,
        }));
        return browser;
    }
    async closeBrowser(browser) {
        await browser.close();
        this.logger.log('Browser closed');
    }
};
exports.BrowserService = BrowserService;
exports.BrowserService = BrowserService = BrowserService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [proxy_service_1.ProxyService])
], BrowserService);
//# sourceMappingURL=browser.service.js.map