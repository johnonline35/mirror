"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuietStartupLogger = void 0;
const common_1 = require("@nestjs/common");
class QuietStartupLogger extends common_1.ConsoleLogger {
    constructor(enableStartupLogs) {
        super();
        const x = [
            'RoutesResolver',
            'RouterExplorer',
            'InstanceLoader',
            'NestFactory',
        ];
        this.ignoreContexts = enableStartupLogs ? new Set(x) : new Set();
    }
    log(message, ...optionalParams) {
        if (this.shouldSuppress(optionalParams)) {
            return;
        }
        super.log(message, ...optionalParams);
    }
    warn(message, ...optionalParams) {
        if (this.shouldSuppress(optionalParams)) {
            return;
        }
        super.warn(message, ...optionalParams);
    }
    debug(message, ...optionalParams) {
        if (this.shouldSuppress(optionalParams)) {
            return;
        }
        super.debug(message, ...optionalParams);
    }
    error(message, ...optionalParams) {
        if (this.shouldSuppress(optionalParams)) {
            return;
        }
        super.error(message, ...optionalParams);
    }
    shouldSuppress(optionalParams) {
        if (optionalParams?.length && this.ignoreContexts.has(optionalParams[0])) {
            return true;
        }
        return false;
    }
}
exports.QuietStartupLogger = QuietStartupLogger;
//# sourceMappingURL=quiet-logger.js.map