"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const bootstrap_1 = require("./bootstrap");
const puppeteer_service_1 = require("./puppeteer/puppeteer.service");
const lambda_warmer_1 = __importDefault(require("lambda-warmer"));
let nestApp;
const handler = async (event) => {
    console.log('inside lambda handler', JSON.stringify(event, null, 2));
    if (!nestApp) {
        nestApp = await (0, bootstrap_1.bootstrap)();
    }
    if (await (0, lambda_warmer_1.default)(event))
        return 'warmed';
    const puppeteerService = nestApp.get(puppeteer_service_1.PuppeteerService);
    try {
        let url;
        if (event.body && typeof event.body === 'string') {
            try {
                const body = JSON.parse(event.body);
                url = body.url;
            }
            catch (parseError) {
                console.error('Error parsing event body:', parseError);
                return {
                    statusCode: 400,
                    body: JSON.stringify({ error: 'Invalid JSON in request body' }),
                };
            }
        }
        else if (event.queryStringParameters && event.queryStringParameters.url) {
            url = event.queryStringParameters.url;
        }
        else {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    error: 'URL not provided in request body or query parameters',
                }),
            };
        }
        if (!url) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'URL is required' }),
            };
        }
        const html = await puppeteerService.runPuppeteer(url);
        return {
            statusCode: 200,
            body: JSON.stringify({ html }),
        };
    }
    catch (error) {
        console.error('Error in Lambda Handler:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: error.message || 'An unexpected error occurred',
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map