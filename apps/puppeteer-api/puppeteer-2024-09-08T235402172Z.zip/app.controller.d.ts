export declare class AppController {
    healthCheck(): {
        status: string;
    };
}
