"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bootstrap = bootstrap;
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const quiet_logger_1 = require("./quiet-logger");
async function bootstrap() {
    const app = await core_1.NestFactory.createApplicationContext(app_module_1.AppModule, {
        logger: new quiet_logger_1.QuietStartupLogger(true),
    });
    return app;
}
//# sourceMappingURL=bootstrap.js.map