export declare const handler: (event: any) => Promise<"warmed" | {
    statusCode: number;
    body: string;
}>;
