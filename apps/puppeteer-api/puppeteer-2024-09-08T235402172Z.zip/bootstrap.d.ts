export declare function bootstrap(): Promise<import("@nestjs/common").INestApplicationContext>;
